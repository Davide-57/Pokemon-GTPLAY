package it.gtplay.pokemon.viewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData

class TrainerViewModel(application: Application) : AndroidViewModel(application)  {
    var messageTerminated: MutableLiveData<MutableList<Int>> = MutableLiveData()

    init {
        messageTerminated.value = mutableListOf(0,0)
    }
}