package it.gtplay.pokemon.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.squareup.picasso.Picasso
import it.gtplay.pokemon.PokeShow
import it.gtplay.pokemon.R
import it.gtplay.pokemon.databinding.FragmentEvolutionBinding
import it.gtplay.pokemon.persistence.DbPokemon
import it.gtplay.pokemon.persistence.Pokemon
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class EvolutionFragment : Fragment() {
    private lateinit var binding: FragmentEvolutionBinding

    //id normalized in string with 3 characters
    private var position1 = ""
    private var position2 = ""
    private var position3 = ""
    private var position4 = ""
    private var position5 = ""
    private var position6 = ""
    private var position7 = ""
    private var position8 = ""
    private var position9 = ""
    private var position10 = ""
    private var position11 = ""
    private var position12 = ""
    private var position13 = ""
    private var position14 = ""
    private var position15 = ""
    private var position16 = ""


    //number id to create bundle intent
    private var id1 = 0
    private var id2 = 0
    private var id3 = 0
    private var id4 = 0
    private var id5 = 0
    private var id6 = 0
    private var id7 = 0
    private var id8 = 0
    private var id9 = 0
    private var id10 = 0
    private var id11 = 0
    private var id12 = 0
    private var id13 = 0
    private var id14 = 0
    private var id15 = 0
    private var id16 = 0

    private var level1 = 0
    private var item1 = ""
    private var happiness1 = 0
    private var method1 = ""

    private var level2 = 0
    private var item2 = ""
    private var happiness2 = 0
    private var method2 = ""

    private var level3 = 0
    private var item3 = ""
    private var happiness3 = 0
    private var method3 = ""

    private var level4 = 0
    private var item4 = ""
    private var happiness4 = 0
    private var method4 = ""

    private var level5 = 0
    private var item5 = ""
    private var happiness5 = 0
    private var method5 = ""

    private var level6 = 0
    private var item6 = ""
    private var happiness6 = 0
    private var method6 = ""

    private var level7 = 0
    private var item7 = ""
    private var happiness7 = 0
    private var method7 = ""

    private var level8 = 0
    private var item8 = ""
    private var happiness8 = 0
    private var method8 = ""

    private val baseUrlImg = "https://assets.pokemon.com/assets/cms2/img/pokedex/full/"


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentEvolutionBinding.inflate(layoutInflater, container, false)

        val number = this.requireArguments().getInt("num", 1)
        val index = number - 1

        val db = DbPokemon.getInstance(this.requireActivity())
        CoroutineScope(Dispatchers.IO).launch {
            val pokedex: List<Pokemon>


            pokedex = db.pokeDao().loadOrdered()
            val name = pokedex[index].name

            val countBaseForm = db.pokeDao().countBaseForm(name)
            var countFirstEvolution = db.pokeDao().countFirstEvolution(name)
            val countSecondEvolution = db.pokeDao().countSecondEvolution(name)


            //hp,atks,def,ats,defs,speed
            if(countBaseForm > 0) {
                //BASEFORM
                id1 = number
                position1 = generateId(number)
                val nameFirstEvolution = db.pokeDao().loadNameFirstEvolution(name)
                if(countBaseForm == 1){
                    //the pokemon has only one evolution chain
                    if(nameFirstEvolution == ""){
                        //non ha catena evolutiva
                        launch(Dispatchers.Main){
                            binding.evone.isVisible = false
                            binding.line1.isVisible =false
                            binding.evtwo.isVisible = false
                            binding.line2.isVisible = false
                            binding.evthree.isVisible = false



                        }



                    }
                    else {
                        //almeno un evoluzione
                        //immagine base
                        id2 = db.pokeDao().getIdByName(nameFirstEvolution)
                        position2 = generateId(id2)
                        level1 = db.pokeDao().loadLevel1(name)
                        item1 = db.pokeDao().loadItem1(name)
                        happiness1 = db.pokeDao().loadHappiness1(name)
                        method1 = db.pokeDao().loadMethod1(name)

                        launch(Dispatchers.Main) {
                            binding.line2.isVisible = false
                            binding.evthree.isVisible = false

                        }


                        //immagine prima
                        val nameSecondEvolution = db.pokeDao().loadNameSecondEvolution(name)
                        if (nameSecondEvolution == ""){
                            //ha solo la prima evoluzione
                            launch(Dispatchers.Main) {
                                binding.line1.isVisible = false
                                binding.evtwo.isVisible = false
                                binding.line2.isVisible = false
                                binding.evthree.isVisible = false

                            }
                        }
                        else{
                            //ha tutte le evoluzioni
                            //immagine seconda
                            id3 = id2
                            id4 = db.pokeDao().getIdByName(nameSecondEvolution)
                            position3 = position2
                            position4 = generateId(id4)
                            level2 = db.pokeDao().loadLevel2(name)
                            item2 = db.pokeDao().loadItem2(name)
                            happiness2 = db.pokeDao().loadHappiness2(name)
                            method2 = db.pokeDao().loadMethod2(name)
                            launch(Dispatchers.Main) {
                                binding.line2.isVisible = false
                                binding.evthree.isVisible = false

                            }
                        }
                    }
                }
                else if(countBaseForm == 2){
                    //the pokemon has two evolution line
                    countFirstEvolution = db.pokeDao().countFirstEvolution(nameFirstEvolution)
                    if(countFirstEvolution == 1){
                        //it means that there are two first evolution
                        val pairEvolutionChain = db.pokeDao().loadEvolutions(name)

                        id2 = db.pokeDao().getIdByName(pairEvolutionChain[0].first_evolution)
                        position2 = generateId(id2)
                        level1 = pairEvolutionChain[0].level1
                        item1 = pairEvolutionChain[0].item1
                        happiness1 = pairEvolutionChain[0].happiness1
                        method1 = pairEvolutionChain[0].method1

                        id3 = id1
                        position3 = position1
                        id4 = db.pokeDao().getIdByName(pairEvolutionChain[1].first_evolution)
                        position4 = generateId(id4)
                        level2 = pairEvolutionChain[1].level1
                        item2 = pairEvolutionChain[1].item1
                        happiness2 = pairEvolutionChain[1].happiness1
                        method2 = pairEvolutionChain[1].method1

                        launch(Dispatchers.Main) {
                            binding.line2.isVisible = false
                            binding.evthree.isVisible = false

                        }
                    }
                    else{
                        //else there are two second evolution
                        val pairEvolutionChain = db.pokeDao().loadEvolutions(name)

                        id2 = db.pokeDao().getIdByName(pairEvolutionChain[0].first_evolution)
                        position2 = generateId(id2)
                        level1 = pairEvolutionChain[0].level1
                        item1 = pairEvolutionChain[0].item1
                        happiness1 = pairEvolutionChain[0].happiness1
                        method1 = pairEvolutionChain[0].method1

                        id3 = id2
                        position3 = position2
                        id4 = db.pokeDao().getIdByName(pairEvolutionChain[0].second_evolution)
                        position4 = generateId(id4)
                        level2 = pairEvolutionChain[0].level2
                        item2 = pairEvolutionChain[0].item2
                        happiness2 = pairEvolutionChain[0].happiness2
                        method2 = pairEvolutionChain[0].method2

                        id5 = id2
                        position5 = position2
                        id6 = db.pokeDao().getIdByName(pairEvolutionChain[1].second_evolution)
                        position6 = generateId(id6)
                        level3 = pairEvolutionChain[1].level2
                        item3 = pairEvolutionChain[1].item2
                        happiness3 = pairEvolutionChain[1].happiness2
                        method3 = pairEvolutionChain[1].method2

                    }
                }
                else{
                    //it is eevee or tyrogue. they are special cases
                    if(name == "eevee"){
                        id3 = id1
                        id5 = id1
                        id7 = id1
                        id9 = id1
                        id11 = id1
                        id13 = id1
                        id15 = id1
                        position3 = position1
                        position5 = position1
                        position7 = position1
                        position9 = position1
                        position11 = position1
                        position13 = position1
                        position15 = position1

                        id2 = 134   //vaporeon
                        position2 = generateId(id2)
                        item1 = "water-stone"
                        method1 = "use-item"

                        id4 = 135   //jolteon
                        position4 = generateId(id4)
                        item2 = "electric-stone"
                        method2 = "use-item"

                        id6 = 136   //flareon
                        position6 = generateId(id6)
                        item3 = "fire-stone"
                        method3 = "use-item"

                        id8 = 196   //espeon
                        position8 = generateId(id8)
                        item4 = ""
                        method4 = "level-up"
                        happiness4= 220

                        id10 = 197   //umbreon
                        position10 = generateId(id10)
                        item5 = ""
                        method5 = "level-up"
                        happiness5= 220

                        id12 = 470   //leafeon
                        position12 = generateId(id12)
                        item6 = "leaf-stone"
                        method6 = "use-item"

                        id14 = 471   //glaceon
                        position14 = generateId(id14)
                        item7 = "ice-stone"
                        method7 = "use-item"

                        id16 = 700   //sylveon
                        position16 = generateId(id16)
                        method8 = "level-up"
                        level8 = 1

                        launch(Dispatchers.Main) {
                            binding.evfour.isVisible = true
                            binding.line3.isVisible =true
                            binding.evfive.isVisible = true
                            binding.line4.isVisible = true
                            binding.evsix.isVisible = true
                            binding.line5.isVisible =true
                            binding.evseven.isVisible = true
                            binding.line6.isVisible = true
                            binding.eveight.isVisible = true
                            binding.line7.isVisible =true
                            binding.line8.isVisible =true
                        }




                    }
                    else if(name == "tyrogue") {
                        id3 = id1
                        id5 = id1
                        position3 = position1
                        position5 = position1

                        id2 = 106   //hitmonlee
                        position2 = generateId(id2)
                        level1 = 20
                        method1 = "level-up"

                        id4 = 107   //hitmonchan
                        position4 = generateId(id4)
                        level2 = 20
                        method2 = "level-up"

                        id6 = 237   //hitmontop
                        position6 = generateId(id6)
                        level3 = 20
                        method3 = "level-up"
                    }
                }
            }




            else if(countFirstEvolution > 0){
                //this is the first evolution
                id1 = db.pokeDao().getIdByName(db.pokeDao().loadNameBaseForm(name))
                position1 = generateId(id1)

                id2 = number
                position2 = generateId(number)
                level1 = db.pokeDao().loadLevel1(name)
                item1 = db.pokeDao().loadItem1(name)
                happiness1 = db.pokeDao().loadHappiness1(name)
                method1 = db.pokeDao().loadMethod1(name)

                if(countFirstEvolution == 1){

                    //at most this kind of first evolution can evolves in one pokemon
                    val nameSecondEvolution = db.pokeDao().loadNameSecondEvolution(name)

                    if (nameSecondEvolution == "") {
                        //if there isn't a second evolution
                        launch(Dispatchers.Main) {
                            binding.line1.isVisible = false
                            binding.evtwo.isVisible = false
                            binding.line2.isVisible = false
                            binding.evthree.isVisible = false

                        }
                    }
                    //there is a second evolution
                    else{
                        //get the info about the evolution chain of the pokemon
                        id3 = id2
                        position3 = position2
                        id4 = db.pokeDao().getIdByName(nameSecondEvolution)
                        position4 = generateId(id4)
                        level2 = db.pokeDao().loadLevel2(name)
                        item2 = db.pokeDao().loadItem2(name)
                        happiness2 = db.pokeDao().loadHappiness2(name)
                        method2 = db.pokeDao().loadMethod2(name)
                    }
                    launch(Dispatchers.Main) {
                        binding.line2.isVisible = false
                        binding.evthree.isVisible = false

                    }
                }

                else{
                    //this first evolution can evolves in two different pokemon
                    val pairEvolutionChain = db.pokeDao().loadEvolutions(db.pokeDao().loadNameBaseForm(name))
                    //get the info about the evolution chain of the pokemon
                    id3 = id2
                    position3 = position2
                    id4 = db.pokeDao().getIdByName(pairEvolutionChain[0].second_evolution)
                    position4 = generateId(id4)
                    level2 = pairEvolutionChain[0].level2
                    item2 = pairEvolutionChain[0].item2
                    happiness2 = pairEvolutionChain[0].happiness2
                    method2 = pairEvolutionChain[0].method2

                    id5 = id2
                    position5 = position2
                    id6 = db.pokeDao().getIdByName(pairEvolutionChain[1].second_evolution)
                    position6 = generateId(id6)
                    level3 = pairEvolutionChain[1].level2
                    item3 = pairEvolutionChain[1].item2
                    happiness3 = pairEvolutionChain[1].happiness2
                    method3 = pairEvolutionChain[1].method2
                }

            }
            else if(countSecondEvolution>0){
                //the pokemon is a second evolution
                //get the info about the evolution chain of the pokemon
                id1 = db.pokeDao().getIdByName(db.pokeDao().loadNameBaseForm(name))
                position1 = generateId(id1)

                id2 = db.pokeDao().getIdByName(db.pokeDao().loadNameFirstEvolution(name))
                position2 = generateId(id2)
                level1 = db.pokeDao().loadLevel1(name)
                item1 = db.pokeDao().loadItem1(name)
                happiness1 = db.pokeDao().loadHappiness1(name)
                method1 = db.pokeDao().loadMethod1(name)

                id3 = id2
                position3 = position2

                id4 = number
                position4 = generateId(number)
                level2 = db.pokeDao().loadLevel2(name)
                item2 = db.pokeDao().loadItem2(name)
                happiness2 = db.pokeDao().loadHappiness2(name)
                method2 = db.pokeDao().loadMethod2(name)

                launch(Dispatchers.Main) {
                    binding.line2.isVisible = false
                    binding.evthree.isVisible = false

                }
            }

            else{

                //this is a pokemon that has a problem with own name in the api
                id1 = number
                binding.textevone.text = getString(R.string.errorApi)
                binding.circle2.visibility = View.INVISIBLE
                position1 = generateId(id1)
                launch(Dispatchers.Main) {
                    binding.line1.isVisible = false
                    binding.evtwo.isVisible = false
                    binding.line2.isVisible = false
                    binding.evthree.isVisible = false

                }
            }



            launch(Dispatchers.Main) {
                //creation of the evolution layout
                loadLayout(binding, position1, position2, position3, position4, position5, position6,position7, position8, position9, position10, position11, position12,position13, position14, position15, position16)
            }


        }


        //start activity from clicked pokemon of evolution chain
        binding.circle1.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id1))
        }
        binding.circle2.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id2))
        }
        binding.circle3.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id3))
        }
        binding.circle4.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id4))
        }
        binding.circle5.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id5))
        }
        binding.circle6.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id6))
        }
        binding.circle7.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id7))
        }
        binding.circle8.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id8))
        }
        binding.circle9.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id9))
        }
        binding.circle10.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id10))
        }
        binding.circle11.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id11))
        }
        binding.circle12.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id12))
        }
        binding.circle13.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id13))
        }
        binding.circle14.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id14))
        }
        binding.circle15.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id15))
        }
        binding.circle16.setOnClickListener{
            context?.startActivity(Intent(context, PokeShow::class.java).putExtra("num",id16))
        }

        return binding.root
    }


    //managment of the layout
    private fun loadLayout(binding: FragmentEvolutionBinding, position1: String, position2: String, position3: String, position4: String, position5: String, position6: String,position7: String, position8: String, position9: String, position10: String, position11: String,position12: String, position13: String, position14: String, position15: String, position16: String) {

        //with Picasso we take the image of the pokemon
        Picasso.get().load("$baseUrlImg$position1.png").into(binding.circle1)
        if (position2 != ""){
            //with Picasso we take the image of the pokemon
            Picasso.get().load("$baseUrlImg$position2.png").into(binding.circle2)
            if(method1 == "level-up"){
                if(level1 != 0){
                    (getString(R.string.level) + level1).also { binding.textevone.text = it }
                }
                else if(happiness1 != 0){
                    (getString(R.string.happiness) + happiness1).also { binding.textevone.text = it }
                }
                else{
                    binding.textevone.text = getString(R.string.nd)
                }
            }
            else if (method1 == "trade"){
                binding.textevone.text = getString(R.string.trade)
            }
            else if (method1 == "use-item"){
                (getString(R.string.item) + item1).also { binding.textevone.text = it }
            }
            else{
                binding.textevone.text = getString(R.string.nd)
            }
            if (position4 != ""){
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position3.png").into(binding.circle3)
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position4.png").into(binding.circle4)
                if(method2 == "level-up"){
                    if(level2 != 0){
                        (getString(R.string.level) + level2).also { binding.textevtwo.text = it }
                    }
                    else if(happiness2 != 0){
                        (getString(R.string.happiness) + happiness2).also { binding.textevtwo.text = it }
                    }
                    else{
                        binding.textevtwo.text = getString(R.string.nd)
                    }
                }
                else if (method2 == "trade"){
                    binding.textevtwo.text = getString(R.string.trade)
                }
                else if (method2 == "use-item"){
                    (getString(R.string.item) + item2).also { binding.textevtwo.text = it }
                }
                else{
                    binding.textevtwo.text = getString(R.string.nd)
                }

            }
            if(position5 != ""){
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position5.png").into(binding.circle5)
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position6.png").into(binding.circle6)
                if(method3 == "level-up"){
                    if(level3 != 0){
                        (getString(R.string.level) + level3).also { binding.textev3.text = it }
                    }
                    else if(happiness3 != 0){
                        (getString(R.string.happiness) + happiness3).also { binding.textev3.text = it }
                    }
                    else{
                        binding.textev3.text = getString(R.string.nd)
                    }
                }
                else if (method3 == "trade"){
                    binding.textev3.text = getString(R.string.trade)
                }
                else if (method3 == "use-item"){
                    (getString(R.string.item) + item3).also { binding.textev3.text = it }
                }
                else{
                    binding.textev3.text = getString(R.string.nd)
                }
            }
            if(position7 != ""){
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position7.png").into(binding.circle7)
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position8.png").into(binding.circle8)
                if(method4 == "level-up"){
                    if(level4 != 0){
                        (getString(R.string.level) + level4).also { binding.textev4.text = it }
                    }
                    else if(happiness4 != 0){
                        (getString(R.string.happiness) + happiness4).also { binding.textev4.text = it }
                    }
                    else{
                        binding.textev4.text = getString(R.string.nd)
                    }
                }
                else if (method4 == "trade"){
                    binding.textev4.text = getString(R.string.trade)
                }
                else if (method4 == "use-item"){
                    (getString(R.string.item) + item3).also { binding.textev4.text = it }
                }
                else{
                    binding.textev4.text = getString(R.string.nd)
                }
            }
            if(position9 != ""){
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position9.png").into(binding.circle9)
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position10.png").into(binding.circle10)
                if(method5 == "level-up"){
                    if(level5 != 0){
                        (getString(R.string.level) + level5).also { binding.textev5.text = it }
                    }
                    else if(happiness5 != 0){
                        (getString(R.string.happiness) + happiness5).also { binding.textev5.text = it }
                    }
                    else{
                        binding.textev5.text = getString(R.string.nd)
                    }
                }
                else if (method5 == "trade"){
                    binding.textev5.text = getString(R.string.trade)
                }
                else if (method5 == "use-item"){
                    (getString(R.string.item) + item5).also { binding.textev5.text = it }
                }
                else{
                    binding.textev5.text = getString(R.string.nd)
                }
            }
            if(position11 != ""){
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position11.png").into(binding.circle11)
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position12.png").into(binding.circle12)
                if(method6 == "level-up"){
                    if(level6 != 0){
                        (getString(R.string.level) + level6).also { binding.textev6.text = it }
                    }
                    else if(happiness6 != 0){
                        (getString(R.string.happiness) + happiness6).also { binding.textev6.text = it }
                    }
                    else{
                        binding.textev6.text = getString(R.string.nd)
                    }
                }
                else if (method6 == "trade"){
                    binding.textev6.text = getString(R.string.trade)
                }
                else if (method6 == "use-item"){
                    (getString(R.string.item) + item6).also { binding.textev6.text = it }
                }
                else{
                    binding.textev6.text = getString(R.string.nd)
                }
            }
            if(position13 != ""){
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position13.png").into(binding.circle13)
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position14.png").into(binding.circle14)
                if(method7 == "level-up"){
                    if(level7 != 0){
                        (getString(R.string.level) + level7).also { binding.textev7.text = it }
                    }
                    else if(happiness7 != 0){
                        (getString(R.string.happiness) + happiness7).also { binding.textev7.text = it }
                    }
                    else{
                        binding.textev7.text = getString(R.string.nd)
                    }
                }
                else if (method7 == "trade"){
                    binding.textev7.text = getString(R.string.trade)
                }
                else if (method7 == "use-item"){
                    (getString(R.string.item) + item7).also { binding.textev7.text = it }
                }
                else{
                    binding.textev7.text = getString(R.string.nd)
                }
            }
            if(position15 != ""){
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position15.png").into(binding.circle15)
                //with Picasso we take the image of the pokemon
                Picasso.get().load("$baseUrlImg$position16.png").into(binding.circle16)
                if(method8 == "level-up"){
                    if(level8 != 0){
                        //binding.textev8.text = "Level: ND "
                        binding.textev8.text = getString(R.string.levelSylveon) // only for sylveon

                    }
                    else if(happiness8 != 0){
                        (getString(R.string.happiness) + happiness8).also { binding.textev8.text = it }
                    }
                    else{
                        binding.textev8.text = getString(R.string.nd)
                    }
                }
                else if (method8 == "trade"){
                    binding.textev8.text = getString(R.string.trade)
                }
                else if (method8 == "use-item"){
                    (getString(R.string.item) + item8).also { binding.textev8.text = it }
                }
                else{
                    binding.textev8.text = getString(R.string.nd)
                }
            }
        }
    }


    private fun generateId(number: Int): String{
        var temp = (number).toString()
        if (temp.length == 1){
            temp = "00" + (number).toString()
        }
        else if (temp.length == 2){
            temp = "0" + (number).toString()
        }
        return temp
    }
}