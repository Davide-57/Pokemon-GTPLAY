package it.gtplay.pokemon.persistence

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Move (@PrimaryKey var name: String,
                 var id: Int,
                 var power: Int,
                 var pp: Int,
                 var accuracy: Int,
                 var type_name: String,
                 var damage_type: String,
                 var url: String)