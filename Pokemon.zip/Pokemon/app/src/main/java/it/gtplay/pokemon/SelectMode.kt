package it.gtplay.pokemon

interface SelectMode {
    fun onSelect(size: Int)
}
