package it.gtplay.pokemon.persistence


data class JoinPokeMove(
    var pokemon: String,
    var move: String,
    var power: Int,
    var pp: Int,
    var type_name: String,
    var damage_type: String,
    var accuracy: Int,
    var level: Int,
    var method: String)