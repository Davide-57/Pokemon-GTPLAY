package it.gtplay.pokemon.fragments

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.data.RadarData
import com.github.mikephil.charting.data.RadarDataSet
import com.github.mikephil.charting.data.RadarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.interfaces.datasets.IRadarDataSet
import it.gtplay.pokemon.R
import it.gtplay.pokemon.databinding.FragmentStatsBinding
import it.gtplay.pokemon.persistence.DbPokemon
import it.gtplay.pokemon.persistence.Pokemon
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class StatsFragment : Fragment() {
    private lateinit var binding: FragmentStatsBinding
    //private val viewModel: CommViewModel by activityViewModels()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentStatsBinding.inflate(layoutInflater, container, false)

        //recovering data from database to provide information to inflate radarchart, shape and abilities of the pokemon
        val number = this.requireArguments().getInt("num", 1)
        val index = number - 1
        val db = DbPokemon.getInstance(this.requireActivity())
        CoroutineScope(Dispatchers.IO).launch {
            val pokedex: List<Pokemon>


            pokedex = db.pokeDao().loadOrdered()
            val hp = pokedex[index].hp
            val atk = pokedex[index].atk
            val def = pokedex[index].def
            val speed = pokedex[index].speed
            val defs = pokedex[index].defs
            val ats = pokedex[index].atks
            val abilityfirst = pokedex[index].ability1
            val abilitysecond = pokedex[index].ability2

            val weight = (pokedex[index].weight/10f).toString() + "kg"
            val height = (pokedex[index].height/10f).toString() + "m"

            launch(Dispatchers.Main){
                //creation of the data for radarchart

                form(height,weight)
                abilities(abilityfirst,abilitysecond)

                val chartList1: ArrayList<RadarEntry> = ArrayList()

                chartList1.add(RadarEntry(hp.toFloat()))
                chartList1.add(RadarEntry(atk.toFloat()))
                chartList1.add(RadarEntry(def.toFloat()))
                chartList1.add(RadarEntry(speed.toFloat()))
                chartList1.add(RadarEntry(defs.toFloat()))
                chartList1.add(RadarEntry(ats.toFloat()))

                val chartList2: ArrayList<RadarEntry> = ArrayList()

                chartList2.add(RadarEntry(200f))
                chartList2.add(RadarEntry(200f))
                chartList2.add(RadarEntry(200f))
                chartList2.add(RadarEntry(200f))
                chartList2.add(RadarEntry(200f))
                chartList2.add(RadarEntry(200f))

                radar(chartList1, chartList2)
            }

        }

        return binding.root
    }
    //show weight and height of the current pokemon
    private fun form(height: String, weight: String){
        binding.weightdata.text = weight
        binding.heightdata.text = height
    }
    //show abilities of pokemons
    private fun abilities(abilityfirst: String, abilitysecond: String){
        binding.abilityone.text = abilityfirst
        if (abilitysecond != ""){
            binding.abilitytwo.text = abilitysecond
        }
    }

    private fun radar(chartList1: ArrayList<RadarEntry> = ArrayList(), chartList2: ArrayList<RadarEntry> = ArrayList()){
        //creation of the radarChart with information about the current pokemon
        val set1 = RadarDataSet(chartList1, "first")
        set1.color = ContextCompat.getColor(context as Activity, R.color.grass)
        set1.fillColor = ContextCompat.getColor(context as Activity, R.color.grass)
        set1.fillAlpha = 200
        set1.lineWidth = 1f
        set1.setDrawFilled(true)
        set1.setDrawHighlightIndicators(true)
        set1.isDrawHighlightCircleEnabled = false

        val set2 =RadarDataSet(chartList2, "second")
        set2.color = ContextCompat.getColor(context as Activity, R.color.grass)
        set2.fillColor = ContextCompat.getColor(context as Activity, R.color.grass)
        set2.fillAlpha = 0
        set2.lineWidth = 0f
        set2.setDrawFilled(false)
        set2.setDrawHighlightIndicators(false)
        set2.isDrawHighlightCircleEnabled = false
        set2.isVisible = false

        val sets = ArrayList<IRadarDataSet>()

        sets.add(set1)
        sets.add(set2)

        val labels = arrayOf(getString(R.string.hp),getString(R.string.attack),getString(R.string.defense),getString(
                    R.string.speed),getString(R.string.spdefense),getString(R.string.spattack))
        val data= RadarData(sets)
        data.setDrawValues(true)
        data.setValueTextSize(14f)
        data.setValueTextColor(Color.BLUE)

        binding.radarchart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        binding.radarchart.data = data
        binding.radarchart.yAxis.axisMinimum = 0f
        binding.radarchart.yAxis.axisMaximum = 200f

        binding.radarchart.yAxis.setDrawLabels(false)
        binding.radarchart.description.isEnabled = false
        binding.radarchart.legend.isEnabled = false

        binding.radarchart.invalidate()
    }
}