package it.gtplay.pokemon.persistence

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class PokemonMoves (@PrimaryKey(autoGenerate=true) var id: Int,
                         var pokemon: String,
                         var move: String,
                         var level: Int?,
                         var method: String){
    constructor(): this(0, "", "", 0,"")
}