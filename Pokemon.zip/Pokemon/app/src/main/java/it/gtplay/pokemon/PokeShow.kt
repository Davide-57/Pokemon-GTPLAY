package it.gtplay.pokemon

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.ConnectivityManager
import android.net.Network

import android.os.Bundle
import android.view.animation.AccelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.squareup.picasso.Picasso

import it.gtplay.pokemon.databinding.ActivityPokeShowBinding
import it.gtplay.pokemon.fragments.EvolutionFragment
import it.gtplay.pokemon.fragments.MovesFragment
import it.gtplay.pokemon.fragments.StatsFragment
import it.gtplay.pokemon.persistence.DbPokemon
import it.gtplay.pokemon.persistence.Pokemon

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*


class PokeShow : AppCompatActivity() {
    private lateinit var binding: ActivityPokeShowBinding
    private lateinit var name: String
    var like = 0
    private var number = 0
    private var sound: Int = 1


    private val baseUrlImg = "https://assets.pokemon.com/assets/cms2/img/pokedex/full/"
    private val baseUrlSound = "https://play.pokemonshowdown.com/audio/cries/"

    private lateinit var titles: Array<String>
    private lateinit var adapterViewPager: ViewPagerFragmentAdapter

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPokeShowBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (supportActionBar != null)
            supportActionBar?.hide()


        //get preferences from memory
        val sharedPref = this.getSharedPreferences("setting",Context.MODE_PRIVATE)
        sound = sharedPref.getInt("sound", 1)
        if (sharedPref.getInt("gender", 1) == 1){
            binding.trainer.setImageResource(R.drawable.boy)
        }
        else{
            binding.trainer.setImageResource(R.drawable.girl)
        }

        //setup bottom sheet
        BottomSheetBehavior.from(binding.bottom).apply {

            peekHeight=90
            isHideable = false
            isFitToContents = false
            halfExpandedRatio = 0.4f
            state= BottomSheetBehavior.STATE_HALF_EXPANDED

        }

        val db = DbPokemon.getInstance(this)

        number = intent.getIntExtra("num", 0)
        val index= number - 1

        var pokedex: List<Pokemon>

        CoroutineScope(Dispatchers.IO).launch {
            pokedex = db.pokeDao().loadOrdered()
            launch(Dispatchers.Main) {
                name = pokedex[index].name
                //take type one and type two values from database
                val typeOne = pokedex[index].type1
                val typeTwo = pokedex[index].type2

                //set status bar and navbar with the same color of the background
                status(typeOne)

                like = pokedex[index].favorite


                //few object animator to provide animations to this activity
                val showxtrainer: ObjectAnimator =
                    ObjectAnimator.ofFloat(binding.trainer, "translationX", 200f, 0f).apply {
                        interpolator = AccelerateInterpolator()
                        duration = 700
                    }

                val shake: ObjectAnimator =
                    ObjectAnimator.ofFloat(binding.icon, "translationX", 0f, 20f, -20f, 0f).apply {
                        interpolator = LinearInterpolator()

                        duration = 400
                    }

                val likex: ObjectAnimator =
                    ObjectAnimator.ofFloat(binding.heart, "scaleX", 0f, 1f).apply {
                        interpolator = OvershootInterpolator()
                        duration = 500
                    }
                val likey: ObjectAnimator =
                    ObjectAnimator.ofFloat(binding.heart, "scaleY", 0f, 1f).apply {
                        interpolator = OvershootInterpolator()
                        duration = 500
                    }

                //startup animation
                AnimatorSet().apply {
                    play(showxtrainer)
                    start()
                }
                //startup like preference
                if (like == 1){
                    binding.heart.background = ContextCompat.getDrawable(this@PokeShow, R.drawable.heartred)
                    binding.circletrainer.isVisible = true
                    binding.trainer.isVisible = true
                }


                //when user click heart add or remove the pokemon to Pokemons favorite list
                binding.heart.setOnClickListener {
                    if (like == 0) {
                        like = 1
                        binding.circletrainer.isVisible = true
                        binding.trainer.isVisible = true
                        CoroutineScope(Dispatchers.IO).launch {
                            db.pokeDao().setFavorite(name)
                        }
                        binding.heart.background =
                            ContextCompat.getDrawable(this@PokeShow, R.drawable.heartred)
                        AnimatorSet().apply {
                            play(likex).with(likey)
                            start()
                        }
                    } else {
                        binding.circletrainer.isVisible = false
                        binding.trainer.isVisible = false
                        like = 0
                        CoroutineScope(Dispatchers.IO).launch {
                            db.pokeDao().unsetFavorite(name)
                        }
                        binding.heart.background = ContextCompat.getDrawable(this@PokeShow, R.drawable.heart)
                        AnimatorSet().apply {
                            play(likex).with(likey)
                            start()
                        }
                    }
                }

                //when user click on pokemon it make an animation but also his sound if internet connection is available
                binding.icon.setOnClickListener {
                    AnimatorSet().apply {
                        play(shake)
                        start()
                    }
                    playSoundPokemon()
                }

                //background Pokemon not linear but with shade
                var drawable = binding.screen.background as GradientDrawable
                drawable.colors = intArrayOf(Color.parseColor(pick(typeOne)), Color.parseColor(pick(typeTwo)))

                //BACKGROUND TabLayout, only type1
                drawable = GradientDrawable()
                drawable.gradientType = GradientDrawable.LINEAR_GRADIENT
                drawable.shape = GradientDrawable.RECTANGLE
                drawable.orientation = GradientDrawable.Orientation.TL_BR
                drawable.colors = intArrayOf(Color.parseColor(pick(typeOne)) ,Color.parseColor(pick(typeOne)))
                drawable.cornerRadius = 25f

                binding.tabLayout.background = drawable


                //sound setup
                playSoundPokemon()

                //string of a sequence of three number to use the link
                val temp = generateId(number)

                //ID
                binding.number.text = "#${temp}"


                //NAME
                if (name.length >= 13) binding.tv.textSize = 27f
                binding.tv.text = name.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }

                //TYPE ONE
                binding.typeone.text = typeOne.replaceFirstChar {
                    if (it.isLowerCase()) it.titlecase(
                        Locale.getDefault()
                    ) else it.toString()
                }

                //TYPE TWO
                if (typeTwo != null) {
                    binding.typetwo.text = typeTwo.replaceFirstChar {
                        if (it.isLowerCase()) it.titlecase(
                            Locale.getDefault()
                        ) else it.toString()
                    }
                } else {
                    binding.typetwo.isVisible = false
                }

                // PICTURE
                Picasso.get().load("$baseUrlImg$temp.png").placeholder(R.drawable.substitute).into(binding.icon)
            }
        }
        init()
    }
    //the call of pokemon
    private fun playSoundPokemon() {
        //variables foe check of internet before playSoundPokemon
        val cm = this.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork: Network? = cm.activeNetwork
        val isConnected = activeNetwork != null
        //when user want to hear pokemons calls and internet is available
        if (sound == 1) {
            if(isConnected){
                val temp = baseUrlSound + name.replace("-", "").replace("average", "").replace("singlestrike", "").replace("normal", "").replace("altered", "").replace("shayminland", "shaymin").replace("redstriped", "").replace("standard", "").replace("incarnate", "").replace("ordinary", "").replace("aria", "").replace("male", "").replace("shield", "").replace("average", "").replace("baile", "").replace("midday", "").replace("solo", "").replace("redmeteor", "").replace("disguised", "").replace("amped", "").replace("eiscueice", "eiscue").replace("male", "").replace("hero", "") + ".mp3"

                MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .build()
                    )

                    setDataSource(temp)
                    prepare() // might take long! (for buffering, etc)
                    start()
                }
            }
            else{
                Toast.makeText(this@PokeShow,"No internet",Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun init() {
        titles = arrayOf(
            getString(R.string.stats),
            getString(R.string.evolution),
            getString(R.string.moves)
        )

        supportActionBar!!.elevation = 0f
        adapterViewPager = ViewPagerFragmentAdapter(this)

        binding.viewPager.adapter = adapterViewPager
        //binding.viewPager.setPageTransformer(ZoomOut())

        // attaching tab mediator
        TabLayoutMediator(
            binding.tabLayout, binding.viewPager
        ) { tab: TabLayout.Tab, position: Int ->
            tab.text = titles[position]

        }.attach()
    }

    private inner class ViewPagerFragmentAdapter(
        fragmentActivity: FragmentActivity
    ) : FragmentStateAdapter(fragmentActivity) {
        override fun createFragment(position: Int): Fragment {
            when (position) {
                //with putInt we provide pokemon index to fragments
                0 -> {
                    val fragment = StatsFragment()
                    val bundle = Bundle()
                    bundle.putInt("num", number)
                    fragment.arguments = bundle
                    return fragment
                }
                1 -> {
                    val fragment = EvolutionFragment()
                    val bundle = Bundle()
                    bundle.putInt("num", number)
                    fragment.arguments = bundle
                    return fragment
                }
                2 -> {
                    val fragment = MovesFragment()
                    val bundle = Bundle()
                    bundle.putInt("num", number)
                    fragment.arguments = bundle
                    return fragment
                }
            }
            return EvolutionFragment()
        }

        override fun getItemCount(): Int {
            return titles.size
        }
    }


    private fun status(color: String?){
        when(color){
            "electric" ->changeColor(R.color.electro)
            "grass" ->changeColor(R.color.grass)
            "fire" ->changeColor(R.color.fire)
            "water" ->changeColor(R.color.water)
            "poison" ->changeColor(R.color.poison)
            "normal" ->changeColor(R.color.normal)
            "bug" ->changeColor(R.color.bug)
            "ground" ->changeColor(R.color.ground)
            "flying" ->changeColor(R.color.flying)
            "fairy" ->changeColor(R.color.fairy)
            "fighting" ->changeColor(R.color.fighting)
            "psychic" ->changeColor(R.color.psychic)
            "rock" ->changeColor(R.color.rock)
            "ice" ->changeColor(R.color.ice)
            "dragon" ->changeColor(R.color.dragon)
            "ghost" ->changeColor(R.color.ghost)
            "dark" ->changeColor(R.color.dark)
            "steel" ->changeColor(R.color.steel)
        }
    }
    private fun changeColor(color: Int){
        window.statusBarColor = ContextCompat.getColor(this, color)
    }
    private fun pick(color: String?): String{
        when(color){
            "electric" -> return "#E5C531"
            "grass" ->return "#71C558"
            "fire" ->return "#EA7A3C"
            "water" ->return "#539AE2"
            "poison" ->return "#B468B7"
            "normal" ->return "#AAB09F"
            "bug" ->return "#94BC4A"
            "ground" ->return "#CC9F4F"
            "flying" ->return "#7DA6DE"
            "fairy" ->return "#E397D1"
            "dragon" ->return "#6A7BAF"
            "ghost" ->return "#846AB6"
            "dark" ->return "#736C75"
            "steel" ->return "#89A1B0"
            "fighting" ->return "#CB5F48"
            "psychic" ->return "#E5709B"
            "rock" ->return "#B2A061"
            "ice" ->return "#70CBD4"
        }
        return "#AAB09F"
    }


    private fun generateId(number: Int): String{
        var temp = (number).toString()
        if (temp.length == 1){
            temp = "00" + (number).toString()
        }
        else if (temp.length == 2){
            temp = "0" + (number).toString()
        }
        return temp
    }


    override fun onBackPressed() {
        //if bottom sheet status is half expanded, with on back pressed we go into the previous activity ,  we call the on back pressed
        if(BottomSheetBehavior.from(binding.bottom).state == BottomSheetBehavior.STATE_HALF_EXPANDED || BottomSheetBehavior.from(binding.bottom).state == BottomSheetBehavior.STATE_COLLAPSED){
            super.onBackPressed()
        }
        else{
            //if bottom sheet is not collapsed, half expand the bottom sheet
            BottomSheetBehavior.from(binding.bottom).state = BottomSheetBehavior.STATE_HALF_EXPANDED
        }
    }
}