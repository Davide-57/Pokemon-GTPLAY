package it.gtplay.pokemon

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.animation.AccelerateInterpolator
import android.widget.EditText
import androidx.core.content.ContextCompat
import it.gtplay.pokemon.databinding.ActivitySettingBinding


class SettingActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.statusBarColor = ContextCompat.getColor(this, R.color.grass)


        supportActionBar?.title = "Setting"
        supportActionBar?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#71C558")))
        window.statusBarColor = ContextCompat.getColor(this, R.color.grass)



        // ZOOM GIRL AND BOY
        val zoomInGirlY : ObjectAnimator = ObjectAnimator.ofFloat(binding.girl, "scaleY",1f,1.1f).apply {

            interpolator = AccelerateInterpolator()
            duration = 500
        }

        val zoomInGirlX: ObjectAnimator = ObjectAnimator.ofFloat(binding.girl, "scaleX",1f,1.1f).apply{
            interpolator = AccelerateInterpolator()
            duration = 500
        }
        val zoomInBoyY : ObjectAnimator = ObjectAnimator.ofFloat(binding.boy, "scaleY",1f,1.1f).apply {

            interpolator = AccelerateInterpolator()
            duration = 500
        }

        val zoomInBoyX : ObjectAnimator = ObjectAnimator.ofFloat(binding.boy, "scaleX",1f,1.1f).apply{
            interpolator = AccelerateInterpolator()
            duration = 500
        }


        // ZOOM OUT GIRL AND BOY
        val zoomOutGirlY : ObjectAnimator = ObjectAnimator.ofFloat(binding.girl, "scaleY",1.1f,1f).apply {

            interpolator = AccelerateInterpolator()
            duration = 500
        }

        val zoomOutGirlX : ObjectAnimator = ObjectAnimator.ofFloat(binding.girl, "scaleX",1.1f,1f).apply{
            interpolator = AccelerateInterpolator()
            duration = 500
        }
        val zoomOutBoyY : ObjectAnimator = ObjectAnimator.ofFloat(binding.boy, "scaleY",1.1f,1f).apply {

            interpolator = AccelerateInterpolator()
            duration = 500
        }

        val zoomOutBoyX : ObjectAnimator = ObjectAnimator.ofFloat(binding.boy, "scaleX",1.1f,1f).apply{
            interpolator = AccelerateInterpolator()
            duration = 500
        }



        //take settings values data from shared and show them on screen
        val sharedPref = this.getSharedPreferences("setting",Context.MODE_PRIVATE)

        if (sharedPref.getInt("sound",1) == 1){
            binding.on.backgroundTintList = resources.getColorStateList(R.color.grass,null)
            binding.off.backgroundTintList = resources.getColorStateList(R.color.normal,null)
        }
        else{
            binding.on.backgroundTintList = resources.getColorStateList(R.color.normal,null)
            binding.off.backgroundTintList = resources.getColorStateList(R.color.grass,null)
        }

        binding.editTextTextPersonName.setText(sharedPref.getString("name", ""))


        binding.on.setOnClickListener{
            sharedPref.edit().putInt("sound", 1).apply()
            binding.on.backgroundTintList = resources.getColorStateList(R.color.grass,null)
            binding.off.backgroundTintList = resources.getColorStateList(R.color.normal,null)
        }
        binding.off.setOnClickListener{
            sharedPref.edit().putInt("sound", 0).apply()
            binding.on.backgroundTintList = resources.getColorStateList(R.color.normal,null)
            binding.off.backgroundTintList = resources.getColorStateList(R.color.grass,null)
        }

        var stat = sharedPref.getInt("gender", 0)
        if (stat ==1){
            binding.girl.backgroundTintList = resources.getColorStateList(R.color.disable,null)
            binding.boy.backgroundTintList = null
        }
        else{
            binding.boy.backgroundTintList = resources.getColorStateList(R.color.disable,null)
            binding.girl.backgroundTintList = null
        }
        binding.boy.setOnClickListener{
            if (stat ==0) {
                stat = 1
                binding.girl.backgroundTintList =
                    resources.getColorStateList(R.color.disable,null)
                binding.boy.backgroundTintList = null

                AnimatorSet().apply {
                    play(zoomInBoyX).with(zoomInBoyY).with(zoomOutGirlX).with(zoomOutGirlY)
                    start()
                }
            }
            sharedPref.edit().putInt("gender", stat).apply()
        }
        binding.girl.setOnClickListener{
            if (stat ==1){
                stat = 0
                binding.boy.backgroundTintList =
                    resources.getColorStateList(R.color.disable,null)
                binding.girl.backgroundTintList = null
                binding.girl.elevation = 20f
                AnimatorSet().apply {
                    play(zoomInGirlX).with(zoomInGirlY).with(zoomOutBoyX).with(zoomOutBoyY)
                    start()
                }
            }
            sharedPref.edit().putInt("gender", stat).apply()
        }

        //check user changes of name in editext
        val textview: EditText = binding.editTextTextPersonName
        textview.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }
            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                sharedPref.edit().putString("name", textview.text.toString()).apply()

            }
            override fun afterTextChanged(arg0: Editable) {
                sharedPref.edit().putString("name", textview.text.toString()).apply()
            }
        })

    }
}