package it.gtplay.pokemon.fragments

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import com.squareup.picasso.Picasso
import it.gtplay.pokemon.R
import it.gtplay.pokemon.databinding.FragmentTrainerBinding
import it.gtplay.pokemon.viewModel.TrainerViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class IntroFragment : Fragment(), IntroToMain {
    private lateinit var binding: FragmentTrainerBinding
    private val model: TrainerViewModel by viewModels()
    private lateinit var mListener: IntroToMain
    private val baseUrlImg = "https://assets.pokemon.com/assets/cms2/img/pokedex/full/"


    override fun onAttach(context: Context) {
        super.onAttach(context)
        mListener = if(context is IntroToMain)
            context
        else
            this
    }



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTrainerBinding.inflate(layoutInflater, container, false)
        val objRotate : ObjectAnimator = ObjectAnimator.ofFloat(binding.pokeball, "rotationY",0f,180f).apply {

            interpolator = LinearInterpolator()
            duration =  4000
            repeatCount = ObjectAnimator.INFINITE

        }
        //Now Professor start to talk with a delay of 1 second
        AnimatorSet().apply {
            play(objRotate)
            start()
        }

        Picasso.get().load(baseUrlImg + "572" + ".png").into(binding.pokemon)
        CoroutineScope(Dispatchers.IO).launch {
            delay(1000)
            showMessage()
        }


        val observer = Observer<MutableList<Int>> { list ->
            mListener.endMessage(list)
        }
        model.messageTerminated.observe(requireActivity(), observer)


        return binding.root
    }
    //this fun make possible to show a message as a natural speach , it write speach letter by letter delayed of 100ms
    private fun showMessage() {
        CoroutineScope(Dispatchers.IO).launch {
            var messaggio = getString(R.string.hi)
            var i = 1
            launch(Dispatchers.Main) {
                while (i <= messaggio.length){
                    (binding.textview.text.toString() +messaggio.subSequence(i-1, i)).also { binding.textview.text = it }
                    i++
                    binding.scrolla.post {
                        binding.scrolla.fullScroll(View.FOCUS_DOWN)
                    }
                    delay(100)
                }
                //the while skips last char because it go out of bound
                (binding.textview.text.toString() +getString(R.string.slash_n)).also { binding.textview.text = it }

                delay(100)
                messaggio = getString(R.string.aralia)
                i = 1
                while ( i <= messaggio.length ){
                    (binding.textview.text.toString()+messaggio.subSequence(i-1, i)).also { binding.textview.text = it }
                    i++
                    delay(100)
                    binding.scrolla.post {
                        binding.scrolla.fullScroll(View.FOCUS_DOWN)
                    }
                }
                //the while skips last char because it go out of bound
                (binding.textview.text.toString() + getString(R.string.slash_n)).also { binding.textview.text = it }
                delay(100)
                messaggio = getString(R.string.info)
                i = 1
                while ( i <= messaggio.length ){
                    (binding.textview.text.toString() +messaggio.subSequence(i-1, i)).also { binding.textview.text = it }
                    i++
                    delay(100)
                    binding.scrolla.post {
                        binding.scrolla.fullScroll(View.FOCUS_DOWN)
                    }
                }
                //the while skips last char because it go out of bound
                (binding.textview.text.toString() + getString(R.string.escl)).also { binding.textview.text = it }

                model.messageTerminated.value = mutableListOf(1,0)
            }
        }
    }

    override fun endMessage(list: MutableList<Int>) {
        TODO("Not yet implemented")
    }
}