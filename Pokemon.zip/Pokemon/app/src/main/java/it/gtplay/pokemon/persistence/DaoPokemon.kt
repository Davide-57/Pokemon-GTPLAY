package it.gtplay.pokemon.persistence

import androidx.room.*

@Dao
interface DaoPokemon {
    @Insert
    fun insertAll(pokedex: List<Pokemon>)

    @Insert
    fun insert(pokedex: Pokemon)

    @Insert
    fun insertMove(move: Move)

    @Insert
    fun insertPokemonMoves(pokeMove: PokemonMoves)

    @Insert
    fun insertEvolutionChain(evolutionChain: EvolutionChain)

    @Update//(onConflict = OnConflictStrategy.REPLACE)
    fun update(pokemon: Pokemon)

    /*@Query("UPDATE Pokemon SET base_happiness = :baseH WHERE name = :namePokemon")
    fun updatePoke(namePokemon: String, baseH: Int)*/

    @Query("DELETE FROM Pokemon")
    fun deleteAll()

    @Query("DELETE FROM Move" )
    fun deleteMove()

    @Query("DELETE FROM PokemonMoves")
    fun deletePokemonMoves()

    @Query("DELETE FROM EvolutionChain")
    fun deleteEvolutionChain()

    @Delete
    fun delete(pokedex: Pokemon)

    /*@Query("SELECT * FROM Pokemon")
    fun loadAll(): LiveData<List<Pokemon>>*/

    @Query("SELECT * FROM Pokemon WHERE name LIKE :search")
    fun loadAllByName(search: String): MutableList<Pokemon>

    /*@Query("SELECT * FROM Pokemon WHERE name = :lang")
    fun loadAllByLanguage(lang: String) : MutableList<Pokemon>*/

    @Query("SELECT * FROM Pokemon ORDER BY id")
    fun loadOrdered() : MutableList<Pokemon>

    @Query("SELECT count(*) FROM Pokemon")
    fun recordsPokemon(): Int

    @Query("SELECT count(*) FROM Move")
    fun recordsMove(): Int

    @Query("SELECT count(*) FROM PokemonMoves")
    fun recordsPokeMove(): Int

    @Query("SELECT count(*) FROM evolutionchain")
    fun recordsEvolution(): Int

    @Query("SELECT COUNT(*) FROM EvolutionChain WHERE base_form LIKE :name")
    fun countBaseForm(name: String): Int

    @Query("SELECT COUNT(*) FROM EvolutionChain WHERE first_evolution = :name")
    fun countFirstEvolution(name: String) : Int

    @Query("SELECT COUNT(*) FROM EvolutionChain WHERE second_evolution = :name")
    fun countSecondEvolution(name: String) : Int

    @Query("SELECT base_form FROM EvolutionChain WHERE first_evolution LIKE :name OR second_evolution LIKE :name")
    fun loadNameBaseForm(name: String): String

    @Query("SELECT first_evolution FROM EvolutionChain WHERE base_form LIKE :name OR second_evolution LIKE :name")
    fun loadNameFirstEvolution(name: String) : String

    @Query("SELECT second_evolution FROM EvolutionChain WHERE first_evolution LIKE :name OR base_form LIKE :name")
    fun loadNameSecondEvolution(name: String) : String

    @Query("SELECT id FROM Pokemon WHERE name LIKE :name")
    fun getIdByName(name: String): Int

    @Query("SELECT level1 FROM EvolutionChain WHERE base_form LIKE :name OR first_evolution LIKE :name OR second_evolution LIKE :name")
    fun loadLevel1(name: String): Int

    @Query("SELECT method1 FROM EvolutionChain WHERE base_form LIKE :name OR first_evolution LIKE :name OR second_evolution LIKE :name")
    fun loadMethod1(name: String): String

    @Query("SELECT item1 FROM EvolutionChain WHERE base_form LIKE :name OR first_evolution LIKE :name OR second_evolution LIKE :name")
    fun loadItem1(name: String) : String

    @Query("SELECT happiness1 FROM EvolutionChain WHERE base_form LIKE :name OR first_evolution LIKE :name OR second_evolution LIKE :name")
    fun loadHappiness1(name: String) : Int

    @Query("SELECT level2 FROM EvolutionChain WHERE base_form LIKE :name OR first_evolution LIKE :name OR second_evolution LIKE :name")
    fun loadLevel2(name: String): Int

    @Query("SELECT method2 FROM EvolutionChain WHERE base_form LIKE :name OR first_evolution LIKE :name OR second_evolution LIKE :name")
    fun loadMethod2(name: String): String

    @Query("SELECT item2 FROM EvolutionChain WHERE base_form LIKE :name OR first_evolution LIKE :name OR second_evolution LIKE :name")
    fun loadItem2(name: String) : String

    @Query("SELECT happiness2 FROM EvolutionChain WHERE base_form LIKE :name OR first_evolution LIKE :name OR second_evolution LIKE :name")
    fun loadHappiness2(name: String) : Int

    @Query("UPDATE POKEMON SET favorite = 1 WHERE name LIKE :name")
    fun setFavorite(name: String) : Int

    @Query("UPDATE POKEMON SET favorite = 0 WHERE name LIKE :name")
    fun unsetFavorite(name: String) : Int

    @Query("SELECT * FROM Pokemon WHERE favorite = 1 ORDER BY id")
    fun loadFavorites() : MutableList<Pokemon>

    @Query("SELECT * FROM Pokemon WHERE type1 LIKE :search OR type2 LIKE :search ORDER BY id")
    fun loadAllByType(search: String): MutableList<Pokemon>

    @Query("SELECT * FROM Pokemon WHERE name LIKE :search AND favorite = 1")
    fun loadFavoritesByName(search: String): MutableList<Pokemon>

    @Query("SELECT * FROM Pokemon WHERE (type1 LIKE :search OR type2 LIKE :search) AND favorite = 1 ORDER BY id")
    fun loadFavoritesByType(search: String): MutableList<Pokemon>

    @Query("SELECT * FROM EvolutionChain WHERE base_form LIKE :name")
    fun loadEvolutions(name: String) : MutableList<EvolutionChain>

    @Query("SELECT pokemon, move, power, pp, type_name, damage_type, accuracy, level, method FROM PokemonMoves JOIN Move ON PokemonMoves.move = Move.name WHERE pokemon LIKE :name AND method NOT LIKE 'egg' ORDER BY method,level")
    fun loadMovesOf(name: String) : MutableList<JoinPokeMove>

    @Query("SELECT name FROM Pokemon WHERE id LIKE :id")
    fun loadNameById(id: Int) : String

    @Query("SELECT * FROM Pokemon WHERE name LIKE :pokemon AND (type1 LIKE :type OR type2 LIKE :type)")
    fun loadTypedByName(pokemon: String, type: String): MutableList<Pokemon>

    @Query("SELECT * FROM Pokemon WHERE name LIKE :pokemon AND (type1 LIKE :type OR type2 LIKE :type) AND favorite = 1")
    fun loadFavoritesTypedByName(pokemon: String, type: String): MutableList<Pokemon>

    @Query("SELECT * FROM Pokemon ORDER BY name")
    fun loadOrderedAtoZ() : MutableList<Pokemon>

    @Query("SELECT * FROM Pokemon  WHERE (type1 LIKE :type OR type2 LIKE :type) ORDER BY name")
    fun loadOrderedTypeAtoZ(type: String) : MutableList<Pokemon>

    @Query("SELECT * FROM Pokemon WHERE favorite = 1 ORDER BY name")
    fun loadFavoritesAtoZ() : MutableList<Pokemon>

    @Query("SELECT * FROM Pokemon WHERE (type1 LIKE :search OR type2 LIKE :search) AND favorite = 1 ORDER BY name")
    fun loadFavoritesByTypeAtoZ(search: String): MutableList<Pokemon>

    @Query("SELECT * FROM Pokemon WHERE name LIKE :search ORDER BY name")
    fun loadOrderedAtoZByName(search: String) : MutableList<Pokemon>

    @Query("SELECT * FROM Pokemon  WHERE (type1 LIKE :type OR type2 LIKE :type) AND name LIKE :search ORDER BY name")
    fun loadOrderedTypeAtoZByName(search: String, type: String) : MutableList<Pokemon>

    @Query("SELECT * FROM Pokemon WHERE name LIKE :search AND favorite = 1 ORDER BY name")
    fun loadFavoritesAtoZByName(search: String) : MutableList<Pokemon>

    @Query("SELECT * FROM Pokemon WHERE (type1 LIKE :type OR type2 LIKE :type) AND favorite = 1 AND name LIKE :search ORDER BY name")
    fun loadFavoritesByTypeAtoZByName(search: String, type: String): MutableList<Pokemon>

    @Query("SELECT favorite FROM Pokemon WHERE name = :pokemon")
    fun loadFavoriteValueOf(pokemon: String): Int

}