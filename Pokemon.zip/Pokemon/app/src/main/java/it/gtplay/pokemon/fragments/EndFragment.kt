package it.gtplay.pokemon.fragments

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.LinearInterpolator
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import com.squareup.picasso.Picasso
import it.gtplay.pokemon.Home

import it.gtplay.pokemon.R
import it.gtplay.pokemon.databinding.FragmentEndBinding

import it.gtplay.pokemon.viewModel.TrainerViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch


class EndFragment : Fragment(), IntroToMain {
    private lateinit var binding: FragmentEndBinding
    private val baseUrlImg = "https://assets.pokemon.com/assets/cms2/img/pokedex/full/"
    //id normalized in string with 3 characters
    var name : String = ""
    private val model: TrainerViewModel by viewModels()
    private lateinit var mListener: IntroToMain

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mListener = if(context is IntroToMain)
            context
        else
            this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentEndBinding.inflate(layoutInflater, container, false)
        this.requireActivity().window.statusBarColor = ContextCompat.getColor(this.requireActivity(), R.color.white)

        //image of professor's pokemon
        Picasso.get().load(baseUrlImg + "572" + ".png").into(binding.pokemon)

        val sharedPref = this.requireActivity().getSharedPreferences("setting", Context.MODE_PRIVATE)
        name = sharedPref.getString("name", "")!!

        //Now Professor start to talk with a delay of 1 second
        CoroutineScope(Dispatchers.IO).launch {
            delay(1000)
            showMessage()
        }

        val observer = Observer<MutableList<Int>> { list ->
            mListener.endMessage(list)
        }
        model.messageTerminated.observe(requireActivity(), observer)


        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val zoomOutY : ObjectAnimator = ObjectAnimator.ofFloat(binding.trainer, "scaleY",1f,0.2f).apply {

            interpolator = AccelerateInterpolator()
            duration = 1000
        }

        val zoomOutX : ObjectAnimator = ObjectAnimator.ofFloat(binding.trainer, "scaleX",1f,0.2f).apply{
            interpolator = AccelerateInterpolator()
            duration = 1000
        }
        val objRotate : ObjectAnimator = ObjectAnimator.ofFloat(binding.pokeball, "rotationY",0f,180f).apply {

            interpolator = LinearInterpolator()
            duration =  4000
            repeatCount = ObjectAnimator.INFINITE

        }
        AnimatorSet().apply {
            play(objRotate)
            start()
        }
        val bundle = Bundle()
        val gen = bundle.getInt("test", 0)
        if (gen == 1){
            CoroutineScope(Dispatchers.IO).launch {
                launch(Dispatchers.Main) {
                    binding.background.backgroundTintList = resources.getColorStateList(R.color.black,null)
                    binding.pokeball.backgroundTintList = resources.getColorStateList(R.color.black,null)
                    binding.pokemon.isVisible = false
                    binding.container.isVisible = false
                    binding.trainer.backgroundTintList = resources.getColorStateList(R.color.white,null)
                    AnimatorSet().apply {
                        play(zoomOutX).with(zoomOutY)
                        start()
                    }
                    delay(1500)
                    startActivity(Intent(context, Home::class.java))
                }
            }
        }
        super.onViewCreated(view, savedInstanceState)
    }

    //this fun make possible to show a message as a natural speach , it write speach letter by letter delayed of 100ms
    private fun showMessage() {
        CoroutineScope(Dispatchers.IO).launch {
            var messaggio = getString(R.string.thku)
            var i = 1
            while ( i <= messaggio.length ){
                launch(Dispatchers.Main) {
                    (binding.textview.text.toString() +messaggio.subSequence(i-1, i)).also { binding.textview.text = it }
                    i++
                    binding.scrolla.post {
                        binding.scrolla.fullScroll(View.FOCUS_DOWN)
                    }
                }
                delay(100)
            }
            delay(500)
            launch(Dispatchers.Main) {
                messaggio =
                    getString(R.string.meet) + name + getString(R.string.enjoy)
                i = 1
                while ( i <= messaggio.length ){
                    (binding.textview.text.toString()+messaggio.subSequence(i-1, i)).also { binding.textview.text = it }
                    i++
                    delay(100)
                    binding.scrolla.post {
                        binding.scrolla.fullScroll(View.FOCUS_DOWN)
                    }
                }
                delay(500)
                messaggio = getString(R.string.luck)+name+getString(R.string.escl)
                i = 1
                while ( i <= messaggio.length ){
                    (binding.textview.text.toString() +messaggio.subSequence(i-1, i)).also { binding.textview.text = it }
                    i++
                    delay(100)
                    binding.scrolla.post {
                        binding.scrolla.fullScroll(View.FOCUS_DOWN)
                    }
                }
                model.messageTerminated.value = mutableListOf(0,1)
            }
        }
    }

    override fun endMessage(list: MutableList<Int>) {
        TODO("Not yet implemented")
    }
}
