package it.gtplay.pokemon.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import it.gtplay.pokemon.adapter.MovesAdapter
import it.gtplay.pokemon.databinding.FragmentMovesBinding
import it.gtplay.pokemon.persistence.DbPokemon
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MovesFragment : Fragment() {
    private lateinit var binding: FragmentMovesBinding
    private lateinit var adapter: MovesAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentMovesBinding.inflate(layoutInflater, container, false)
        // Inflate the layout for this fragment
        val context = this
        val number = this.requireArguments().getInt("num", 1)

        val db = DbPokemon.getInstance(this.requireActivity())
        CoroutineScope(Dispatchers.IO).launch {

            //we takes from the database the relative pokemon
            val namePokemon = db.pokeDao().loadNameById(number)


            //loadmovesOf return the join between pokemons and moves
            val listOfMoves = db.pokeDao().loadMovesOf(namePokemon)
            launch(Dispatchers.Main) {
                adapter = MovesAdapter(listOfMoves, context)
                binding.rvSelectionChart.adapter = adapter
            }
        }
        return binding.root
    }
}

