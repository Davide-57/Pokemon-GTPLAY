package it.gtplay.pokemon.persistence

import androidx.room.Entity

@Entity (primaryKeys = ["base_form","first_evolution","second_evolution"])
data class EvolutionChain (var base_form: String,
                 var first_evolution: String,
                 var level1: Int,
                 var second_evolution: String,
                 var level2: Int,
                 var method1: String,
                 var item1: String,
                 var item2: String,
                 var method2: String,
                 var happiness1: Int,
                 var happiness2: Int)
{
    constructor(): this("", "", 0, "",0, "", "", "", "", 0,0)
}