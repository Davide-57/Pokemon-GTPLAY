package it.gtplay.pokemon.viewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class CommViewModel: ViewModel(){
    val data: MutableLiveData<MutableList<Int>> = MutableLiveData()
    init {
        data.value = mutableListOf(0,0)
    }

    fun updateData(list: MutableList<Int>) {
        data.value = list
    }
}