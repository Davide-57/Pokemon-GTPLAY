package it.gtplay.pokemon.fragments

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import it.gtplay.pokemon.R
import it.gtplay.pokemon.databinding.FragmentChooseBinding
import it.gtplay.pokemon.viewModel.TrainerViewModel


class ChooseFragment : Fragment(), IntroToMain {
    private lateinit var binding: FragmentChooseBinding

    private val model: TrainerViewModel by viewModels()
    private lateinit var mListener: IntroToMain

    private var stat = 2
    var lastPressed = 2

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mListener = if(context is IntroToMain)
            context
        else
            this
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentChooseBinding.inflate(layoutInflater, container, false)

        //we define few ObjectAnimator to create animation effects when the user select a character
        val objZoomInY : ObjectAnimator = ObjectAnimator.ofFloat(binding.extend, "scaleY",0f,200f).apply {

            interpolator = AccelerateInterpolator()
            duration = 500
        }

        val objZoomInX : ObjectAnimator = ObjectAnimator.ofFloat(binding.extend, "scaleX",0f,200f).apply{
            interpolator = AccelerateInterpolator()
            duration = 500
        }
        val objZoomInGirlY : ObjectAnimator = ObjectAnimator.ofFloat(binding.extendgirl, "scaleY",0f,200f).apply {

            interpolator = AccelerateInterpolator()
            duration = 500
        }

        val objZoomInGirlX : ObjectAnimator = ObjectAnimator.ofFloat(binding.extendgirl, "scaleX",0f,200f).apply{
            interpolator = AccelerateInterpolator()
            duration = 500
        }


        // ZOOM GIRL AND BOY
        val zoomInGirlY : ObjectAnimator = ObjectAnimator.ofFloat(binding.girl, "scaleY",1f,1.2f).apply {

            interpolator = AccelerateInterpolator()
            duration = 500
        }

        val zoomInGirlX : ObjectAnimator = ObjectAnimator.ofFloat(binding.girl, "scaleX",1f,1.2f).apply{
            interpolator = AccelerateInterpolator()
            duration = 500
        }
        val zoomInBoyY : ObjectAnimator = ObjectAnimator.ofFloat(binding.boy, "scaleY",1f,1.2f).apply {

            interpolator = AccelerateInterpolator()
            duration = 500
        }

        val zoomInBoyX : ObjectAnimator = ObjectAnimator.ofFloat(binding.boy, "scaleX",1f,1.2f).apply{
            interpolator = AccelerateInterpolator()
            duration = 500
        }


        // ZOOM OUT GIRL AND BOY
        val zoomOutGirlY : ObjectAnimator = ObjectAnimator.ofFloat(binding.girl, "scaleY",1.2f,1f).apply {

            interpolator = AccelerateInterpolator()
            duration = 500
        }

        val zoomOutGirlX : ObjectAnimator = ObjectAnimator.ofFloat(binding.girl, "scaleX",1.2f,1f).apply{
            interpolator = AccelerateInterpolator()
            duration = 500
        }
        val zoomOutBoyY : ObjectAnimator = ObjectAnimator.ofFloat(binding.boy, "scaleY",1.2f,1f).apply {

            interpolator = AccelerateInterpolator()
            duration = 500
        }

        val zoomOutBoyX : ObjectAnimator = ObjectAnimator.ofFloat(binding.boy, "scaleX",1.2f,1f).apply{
            interpolator = AccelerateInterpolator()
            duration = 500
        }
        this.requireActivity().window.statusBarColor = ContextCompat.getColor(this.requireActivity(), R.color.white)

        //animation to show boy as user character
        binding.boy.setOnClickListener{
            model.messageTerminated.value = mutableListOf(1,0)
            prefer(1)
            if (stat != 0) {
                //this.requireActivity().window.statusBarColor = ContextCompat.getColor(this.requireActivity(), R.color.water)
                //binding.extendgirl.visibility = View.INVISIBLE
                binding.extend.visibility = View.VISIBLE
                binding.extendgirl.elevation = 0f
                binding.girl.elevation = 10f
                binding.extend.backgroundTintList = resources.getColorStateList(R.color.water,null)
                binding.title.setTextColor(resources.getColorStateList(R.color.white,null))
                binding.girl.backgroundTintList = resources.getColorStateList(R.color.disable,null)
                binding.boy.backgroundTintList = null
                binding.extend.elevation = 1f
                binding.boy.elevation = 20f
                AnimatorSet().apply {
                    play(objZoomInX).with(objZoomInY).with(zoomInBoyX).with(zoomInBoyY)
                    start()
                }
                if (lastPressed == 1){
                    AnimatorSet().apply {
                        play(zoomOutGirlY).with(zoomOutGirlX)
                        start()
                    }
                }
                lastPressed = 0
                stat = 0
                val fragment = NameFragment()
                val bundle = Bundle()
                bundle.putInt("gen", 1)
                fragment.arguments = bundle
            }
        }

        //animation to show girl as user character
        binding.girl.setOnClickListener{
            model.messageTerminated.value = mutableListOf(1,0)
            prefer(0)
            if (stat != 1){
                //this.requireActivity().window.statusBarColor = ContextCompat.getColor(this.requireActivity(), R.color.poison)
                //binding.extend.visibility = View.INVISIBLE
                binding.extendgirl.visibility = View.VISIBLE
                binding.extend.elevation = 0f
                binding.boy.elevation = 10f
                binding.extendgirl.backgroundTintList = resources.getColorStateList(R.color.poison,null)
                binding.title.setTextColor(resources.getColorStateList(R.color.white,null))
                binding.boy.backgroundTintList = resources.getColorStateList(R.color.disable,null)
                binding.girl.backgroundTintList = null
                binding.extendgirl.elevation = 1f
                binding.girl.elevation = 20f
                AnimatorSet().apply {
                    play(objZoomInGirlY).with(objZoomInGirlX).with(zoomInGirlX).with(zoomInGirlY)
                    start()
                }
                if (lastPressed == 2){
                    AnimatorSet().apply {
                        play(zoomOutBoyX).with(zoomOutBoyY)
                        start()
                    }
                }
                if (lastPressed == 0){
                    AnimatorSet().apply {
                        play(zoomOutBoyX).with(zoomOutBoyY)
                        start()
                    }
                }
                lastPressed = 1
                stat = 1
                val fragment = NameFragment()
                val bundle = Bundle()
                bundle.putInt("gen", 0)
                fragment.arguments = bundle
            }
        }

        val observer = Observer<MutableList<Int>> { list ->
            mListener.endMessage(list)
        }
        model.messageTerminated.observe(requireActivity(), observer)
        return binding.root
    }


    private fun prefer(type: Int){
        //boy 1 , girl 0
        //set the character selected by user inside shared preferences
        val sharedPref = this.requireActivity().getSharedPreferences("setting",Context.MODE_PRIVATE)
        sharedPref.edit().putInt("gender", type).apply()
    }

    override fun endMessage(list: MutableList<Int>) {
        TODO("Not yet implemented")
    }
}