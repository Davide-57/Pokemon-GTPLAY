package it.gtplay.pokemon

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.SearchView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.ActionMode
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import com.google.android.material.bottomsheet.BottomSheetBehavior
import it.gtplay.pokemon.adapter.PokeAdapter
import it.gtplay.pokemon.databinding.ActivityHomeBinding
import it.gtplay.pokemon.persistence.DbPokemon
import it.gtplay.pokemon.persistence.Pokemon
import it.gtplay.pokemon.viewModel.PokemonVM
import kotlinx.android.synthetic.main.activity_home.view.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class Home: AppCompatActivity(), SelectMode{
    companion object {
        const val TAG = "GTP21"
    }
    private lateinit var binding: ActivityHomeBinding
    private lateinit var pokedex: MutableList<Pokemon>
    private val pokedexVM: PokemonVM by viewModels()
    private lateinit var adapter: PokeAdapter
    var type = ""       //type to use for concatenate filter
    private var statusFavorite = 0          //1 for list of favorites pokemon
    var statusType = 0   //default 0 for name, 1 for type
    var statusAZ = 0 // default -1 : list ordered by id (init), 0: ordered A to Z , 1: ordered Z to A
    var statusReverse=0
    var statusId = 1// default 0 , id by 1 to 898

    var mActionMode : ActionMode? = null
    private var clicked = false

    private val mActionModeCallback: ActionMode.Callback =
        object: ActionMode.Callback{
            override fun onCreateActionMode (mode: ActionMode , menu: Menu ): Boolean{
                mode.menuInflater.inflate(R.menu.menu_action_mode, menu)
                return true
            }

            override fun onPrepareActionMode (mode: ActionMode , menu: Menu ): Boolean{
                return false
            }

            override fun onActionItemClicked (mode: ActionMode , item: MenuItem ): Boolean{
                return when(item.itemId){
                    R.id.favorites ->{
                        adapter.setFavoriteAllSelected()
                        mode.finish()
                        true
                    }
                    R.id.unfavorites ->{
                        AlertDialog.Builder(this@Home)
                            .setTitle(getString(R.string.removefavor))
                            .setMessage(getString(R.string.question))
                            .setPositiveButton(getString(R.string.remove)) { _, _ ->
                                adapter.unsetFavoriteAllSelected()
                                mode.finish()
                            }
                            .setNegativeButton(getString(R.string.back), null)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show()
                        true
                    }

                    else ->{
                        mode.finish()
                        true
                    }
                }
            }

            override fun onDestroyActionMode(mode: ActionMode?) {
                adapter.deselectAll()
                mActionMode = null

            }

        }


    override fun onRestart() {
        super.onRestart()
        adapter.updateImageFavorites(adapter.indexLastPokemonShowed)

        //it is necessary to not show the keyboard
        binding.search.clearFocus()


    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //set actionBar title, background color
        supportActionBar?.title = getString(R.string.Pokedex)
        supportActionBar?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#71C558")))

        //set status bar color
        window.statusBarColor = ContextCompat.getColor(this, R.color.grass)


        setBottom()

        //variables to check internet so we know if we can play Pokemon sounds
        val cm = this.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork: Network? = cm.activeNetwork
        if(activeNetwork == null){
            AlertDialog.Builder(this)
                                .setTitle(getString(R.string.noInternet))
                                .setMessage(getString(R.string.nointernetdialog))
                                .setPositiveButton("Ok",null)
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show()
        }

        //search by type
        binding.alltype.bug.setOnClickListener{
            executeFilterByType("bug", pokedexVM)
        }
        binding.alltype.normal.setOnClickListener{
            executeFilterByType("normal", pokedexVM)
        }
        binding.alltype.fire.setOnClickListener{
            executeFilterByType("fire", pokedexVM)
        }
        binding.alltype.water.setOnClickListener{
            executeFilterByType("water", pokedexVM)
        }
        binding.alltype.grass.setOnClickListener{
            executeFilterByType("grass", pokedexVM)
        }
        binding.alltype.poison.setOnClickListener{
            executeFilterByType("poison", pokedexVM)
        }
        binding.alltype.dark.setOnClickListener{
            executeFilterByType("dark", pokedexVM)
        }
        binding.alltype.psychic.setOnClickListener{
            executeFilterByType("psychic", pokedexVM)
        }
        binding.alltype.dragon.setOnClickListener{
            executeFilterByType("dragon", pokedexVM)
        }
        binding.alltype.fairy.setOnClickListener{
            executeFilterByType("fairy", pokedexVM)
        }
        binding.alltype.ice.setOnClickListener{
            executeFilterByType("ice", pokedexVM)
        }
        binding.alltype.fighting.setOnClickListener{
            executeFilterByType("fighting", pokedexVM)
        }
        binding.alltype.ghost.setOnClickListener{
            executeFilterByType("ghost", pokedexVM)
        }
        binding.alltype.flying.setOnClickListener{
            executeFilterByType("flying", pokedexVM)
        }
        binding.alltype.electric.setOnClickListener{
            executeFilterByType("electric", pokedexVM)
        }
        binding.alltype.ground.setOnClickListener{
            executeFilterByType("ground", pokedexVM)
        }
        binding.alltype.rock.setOnClickListener{
            executeFilterByType("rock", pokedexVM)
        }
        binding.alltype.steel.setOnClickListener{
            executeFilterByType("steel", pokedexVM)
        }


        binding.search.setOnClickListener {

            //we check when we have to hide or show floating buttons
            if(clicked){
                onAddButtonClicked()
            }
        }

        //float menu button
        binding.floatingActionButton.setOnClickListener{
            onAddButtonClicked()
            setBottom()
        }

        binding.floatingActionButton2.setOnClickListener {
            //this button provides the list of button used to filter by type
            BottomSheetBehavior.from(binding.bottom).apply {
                peekHeight=0
                this.state= BottomSheetBehavior.STATE_EXPANDED
                isHideable = true
                onAddButtonClicked()
            }
        }

        binding.floatingActionButton3.setOnClickListener{
            //alphabetic order
            binding.floatingActionButton3.backgroundTintList = resources.getColorStateList(R.color.ice,null)
            binding.floatingActionButton5.backgroundTintList = resources.getColorStateList(R.color.white,null)
            binding.floatingActionButton6.backgroundTintList = resources.getColorStateList(R.color.white,null)
            statusAZ = 1
            statusId = 0
            statusReverse = 0
            binding.search.setOnQueryTextListener(MyQueryListener(pokedexVM, binding, statusType, type, statusFavorite,statusReverse,statusId))
            binding.search.setQuery("", true)

            pokedexVM.filter("", statusType, type, statusFavorite,statusReverse,statusId)

            removeActionMode()

            setBottom()
        }

        binding.floatingActionButton4.setOnClickListener {
            //favorite filter
            if(statusFavorite == 0){
                binding.floatingActionButton4.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.heartred))
                binding.floatingActionButton4.backgroundTintList = resources.getColorStateList(R.color.ice,null)
                statusFavorite = 1
                binding.search.setOnQueryTextListener(MyQueryListener(pokedexVM, binding, statusType, type, statusFavorite,statusReverse,statusId))
                binding.search.setQuery("", true)

                pokedexVM.filter("", statusType, type, statusFavorite,statusReverse,statusId)
            }
            else{
                binding.floatingActionButton4.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.heart))
                binding.floatingActionButton4.backgroundTintList = resources.getColorStateList(R.color.white,null)
                statusFavorite = 0
                binding.search.setOnQueryTextListener(MyQueryListener(pokedexVM, binding, statusType, type, statusFavorite,statusReverse,statusId))
                binding.search.setQuery("", true)

                pokedexVM.filter("", statusType, type, statusFavorite,statusReverse,statusId)
            }

            removeActionMode()

            setBottom()
        }

        binding.floatingActionButton5.backgroundTintList = resources.getColorStateList(R.color.ice,null)
        binding.floatingActionButton5.setOnClickListener{
            //order by id
            binding.floatingActionButton5.backgroundTintList = resources.getColorStateList(R.color.ice,null)
            binding.floatingActionButton3.backgroundTintList = resources.getColorStateList(R.color.white,null)
            binding.floatingActionButton6.backgroundTintList = resources.getColorStateList(R.color.white,null)
            statusAZ = 0
            statusId = 1
            statusReverse = 0
            binding.search.setOnQueryTextListener(MyQueryListener(pokedexVM, binding, statusType, type, statusFavorite,statusReverse,statusId))
            binding.search.setQuery("", true)

            pokedexVM.filter("", statusType, type, statusFavorite,statusReverse,statusId)

            removeActionMode()

            setBottom()
        }

        binding.floatingActionButton6.setOnClickListener{
            //reverse order
            if (statusReverse == 0) {
                statusReverse = 1
                binding.floatingActionButton6.backgroundTintList = resources.getColorStateList(R.color.ice,null)
                binding.search.setOnQueryTextListener(MyQueryListener(pokedexVM, binding, statusType, type, statusFavorite,statusReverse,statusId))
                binding.search.setQuery("", true)

                pokedexVM.filter("", statusType, type, statusFavorite,statusReverse,statusId)
            }
            else{
                statusReverse = 0
                binding.floatingActionButton6.backgroundTintList = resources.getColorStateList(R.color.white,null)
                binding.search.setOnQueryTextListener(MyQueryListener(pokedexVM, binding, statusType, type, statusFavorite,statusReverse,statusId))
                binding.search.setQuery("", true)

                pokedexVM.filter("", statusType, type, statusFavorite,statusReverse,statusId)
            }

            removeActionMode()

            setBottom()

        }

        setUI(binding)
        setLiveData()

    }
    //disable the multiple selection
    private fun removeActionMode() {
        if(mActionMode != null){
            mActionMode!!.finish() // Close Menu
            mActionMode = null
        }
    }


    //every time that a type filter button is clicked, update the query listener
    private fun executeFilterByType(type: String, pokemonVM: PokemonVM) {
        setBottom()
        binding.floatingActionButton2.backgroundTintList = resources.getColorStateList(R.color.ice,null)

        removeActionMode()

        statusType = 1
        this.type = type
        val listener = MyQueryListener(pokedexVM, binding, statusType, type, statusFavorite,statusReverse,statusId)
        binding.search.setOnQueryTextListener(listener)
        binding.search.setQuery("", true)

        pokemonVM.filter("", statusType, type, statusFavorite,statusReverse,statusId)
    }




    //setup of the bottom sheet with all possible pokemon types
    private fun setBottom() {
        BottomSheetBehavior.from(binding.bottom).apply {
            peekHeight=0
            isHideable = true
            this.state= BottomSheetBehavior.STATE_HIDDEN
        }
    }

    private fun onAddButtonClicked() {
        setVisibility(clicked)
        clicked = !clicked
    }
    //set floating buttons status (visible or invisible)
    private fun setVisibility(clicked: Boolean) {
        if (!clicked){
            binding.floatingActionButton2.visibility = View.VISIBLE
            binding.floatingActionButton3.visibility = View.VISIBLE
            binding.floatingActionButton4.visibility = View.VISIBLE
            binding.floatingActionButton5.visibility = View.VISIBLE
            binding.floatingActionButton6.visibility = View.VISIBLE
        }
        else{
            binding.floatingActionButton2.visibility = View.INVISIBLE
            binding.floatingActionButton3.visibility = View.INVISIBLE
            binding.floatingActionButton4.visibility = View.INVISIBLE
            binding.floatingActionButton5.visibility = View.INVISIBLE
            binding.floatingActionButton6.visibility = View.INVISIBLE
        }
    }

    private fun setLiveData() {
        val observer = Observer<List<Pokemon>> { list ->
            if (list != null) {
                Log.w(TAG, "SIZE= " + list.size)
                adapter = PokeAdapter(this@Home, pokedexVM, this, this)
                binding.rvSelectionChart.adapter = adapter
            }
        }
        pokedexVM.lista.observe(this@Home, observer)
    }
    private fun setUI(binding: ActivityHomeBinding) {

        val db = DbPokemon.getInstance(this)
        CoroutineScope(Dispatchers.IO).launch{
            pokedex = db.pokeDao().loadOrdered()
            launch(Dispatchers.Main){
                pokedexVM.lista.value = pokedex

                val listener = MyQueryListener(pokedexVM, binding, statusType, type, statusFavorite,statusReverse,statusId)
                binding.search.setOnQueryTextListener(listener)
                binding.search.setQuery("", true)
            }
        }
    }

    //inflate actionBar menu layout
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_home, menu)
        return super.onCreateOptionsMenu(menu)
    }
    //when user select setting button in actionBar we start a setting activity
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.settings -> {
                val intent = Intent(this, SettingActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.removeFilter -> {
                removeFilter()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    //when user press back button we don't want to close up but to hide floating button or bottom sheet
    override fun onBackPressed() {

        //when filter buttons are not showed
        if(binding.floatingActionButton2.visibility == View.INVISIBLE){
            //when filters are not enabled
            if(statusFavorite == 0 && statusAZ == 0 && statusId == 1 && statusReverse == 0 && statusType == 0){
                CoroutineScope(Dispatchers.IO).launch {
                    launch(Dispatchers.IO) {
                        launch(Dispatchers.Main) {

                            //alert to avoid unwanted exit from app
                            AlertDialog.Builder(this@Home)
                                .setTitle(getString(R.string.closeapp))
                                .setMessage(R.string.question)
                                .setPositiveButton(getString(R.string.stay)) { _, _ ->
                                }
                                .setNegativeButton(getString(R.string.exit)) { _, _ ->
                                    super.onBackPressed()
                                }
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show()
                        }
                    }
                }
            }
            else{
                //not exit by activity, but remove all filter and show default list
                removeFilter()
                setBottom()
            }
        }
        else{
            //when filters button are visible
            onAddButtonClicked()
            setBottom()
        }
    }
    //function to remove filter
    private fun removeFilter() {
        statusFavorite = 0
        statusType = 0
        statusAZ = 0
        statusReverse = 0
        statusId = 1

        setUI(binding)
        binding.floatingActionButton4.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.heart))

        binding.floatingActionButton2.backgroundTintList = resources.getColorStateList(R.color.white,null)
        binding.floatingActionButton3.backgroundTintList = resources.getColorStateList(R.color.white,null)
        binding.floatingActionButton4.backgroundTintList = resources.getColorStateList(R.color.white,null)
        binding.floatingActionButton5.backgroundTintList = resources.getColorStateList(R.color.ice,null)
        binding.floatingActionButton6.backgroundTintList = resources.getColorStateList(R.color.white,null)
    }

    //
    class MyQueryListener(private val pokemonVM: PokemonVM, val binding: ActivityHomeBinding, val statusType: Int, val type: String, val statusFavorite: Int, val statusReverse: Int, val statusId: Int) : SearchView.OnQueryTextListener {

        override fun onQueryTextSubmit(p0: String?): Boolean {
            return false
        }
        override fun onQueryTextChange(p0: String?): Boolean {
            pokemonVM.filter(p0, statusType, type, statusFavorite,statusReverse,statusId)
            BottomSheetBehavior.from(binding.bottom).apply {
                this.state= BottomSheetBehavior.STATE_COLLAPSED
            }

            return false
        }
    }

    override fun onSelect(size: Int) {
        //we use this fun to check if no more item are selected
        if (mActionMode != null) {
            if (size == 0) { // No Selections
                mActionMode!!.finish() // Close Menu
            }
            return
        }
        mActionMode = startSupportActionMode(mActionModeCallback)
    }
}