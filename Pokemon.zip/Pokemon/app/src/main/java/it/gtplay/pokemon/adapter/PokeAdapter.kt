package it.gtplay.pokemon.adapter

import android.app.Activity
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.GradientDrawable.*
import android.util.SparseBooleanArray
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import it.gtplay.pokemon.PokeShow
import it.gtplay.pokemon.R
import it.gtplay.pokemon.SelectMode
import it.gtplay.pokemon.persistence.DbPokemon
import it.gtplay.pokemon.persistence.Pokemon
import it.gtplay.pokemon.viewModel.PokemonVM
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*


class PokeAdapter(val context: Context, private var pokedexVM: PokemonVM, var listener: SelectMode, private val activityHome: Activity) :
    RecyclerView.Adapter<PokeAdapter.Holder>(){

    private val baseUrlImg = "https://assets.pokemon.com/assets/cms2/img/pokedex/full/"

    //it is necessary to update the favorite image when the pokemon is placed / removed from the pokeshow favorites
    var indexLastPokemonShowed = 0

    val db = DbPokemon.getInstance(context)

    var pokedex: List<Pokemon> = emptyList()
    init{
        if (pokedexVM.lista.value != null)
            pokedex = pokedexVM.lista.value!!
    }

    //variables for action mode
    private var mListener = listener
    private var selectedList = SparseBooleanArray()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {

        val constraintLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_card, parent, false) as ConstraintLayout

        return Holder(constraintLayout)
    }




    override fun onBindViewHolder(holder: Holder, position: Int) {
        val name = pokedex[position].name
        val typeOne: String = pokedex[position].type1
        val typeTwo: String? = pokedex[position].type2
        val id = pokedex[position].id

        //id used to start activity PokeShow. It must not be visible
        holder.hideId.text = id.toString()

        holder.name.text = name.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }

        //it is used to remember the selected items when you scroll through the list
        val isSelected = selectedList.get(position, false)
        if(isSelected){
            changeColor("","",holder)
        }
        else{
            changeColor(typeOne,typeTwo,holder)
        }

        //TYPE ONE
        holder.typeOne.text = typeOne.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }

        //if the pokemon is among the favorites, then set the pokeball image visible
        if(pokedex[position].favorite == 1){
            holder.favoriteImage.visibility = View.VISIBLE
        }
        else{
            holder.favoriteImage.visibility = View.INVISIBLE
        }


        //TYPE TWO
        if (typeTwo != null) {
            holder.typeTwo.text = typeTwo.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
            holder.typeTwo.isVisible = true
        } else { holder.typeTwo.isVisible = false }


        //temp is the normalized id with a structure made of *** (* is an int number ) which represents the name of the file on the server
        var temp = (id).toString()
        if (temp.length == 1){
            temp = "00" + (id).toString()
        }
        else if (temp.length == 2){
            temp = "0" + (id).toString()
        }


        //ID
        (context.getString(R.string.hastag) + temp).also { holder.id.text = it }


        //load image of pokemon
        Picasso.get().load("$baseUrlImg$temp.png").into(holder.icon)

        holder.background.setOnClickListener{
            // if selectedList.size is > 0 then the app is in selection mode
            if (selectedList.size() > 0) {
                //this is code in longclick
                val isSel = selectedList.get(position, false)
                if(isSel){
                    //this item is already selected, so now we deselect it
                    it.isSelected = false
                    selectedList.delete(position)
                }
                else{
                    //we change the status of the item from unselected to selected
                    it.isSelected = true
                    selectedList.put(position, true)
                }
                mListener.onSelect(selectedList.size())
                notifyDataSetChanged()
            } else {
                // start the pokeshow activity and set indexLastPokemonShowed as position of the item in view model
                indexLastPokemonShowed = position
                val options = ActivityOptions.makeSceneTransitionAnimation(activityHome, holder.icon, "transition")
                context.startActivity(Intent(context, PokeShow::class.java).putExtra("num",holder.hideId.text.toString().toInt()), options.toBundle())
            }
        }

        holder.background.setOnLongClickListener {
            val isSel = selectedList.get(position, false)
            if(isSel){
                it.isSelected = false
                selectedList.delete(position)
            }
            else{
                it.isSelected = true
                selectedList.put(position, true)
            }
            mListener.onSelect(selectedList.size())
            notifyDataSetChanged()
            return@setOnLongClickListener true
        }


    }

    override fun getItemCount(): Int {
        return pokedex.size
    }

    override fun getItemId(position: Int): Long {
        return pokedex[position].id.toLong()
    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val id: TextView = itemView.findViewById(R.id.id)
        val name: TextView = itemView.findViewById(R.id.name)
        val typeOne: TextView = itemView.findViewById(R.id.typeOne)
        val typeTwo: TextView = itemView.findViewById(R.id.typeTwo)
        val icon: ImageView = itemView.findViewById(R.id.pokeImage)
        val background: RelativeLayout = itemView.findViewById(R.id.card)
        val hideId: TextView = itemView.findViewById(R.id.hideId)
        val favoriteImage: ImageView = itemView.findViewById(R.id.favoriteImage)
    }

    //this fun change the background color of every item inside the adapter with a shade effect
    private fun changeColor(color: String?,colorEnd: String?,holder: Holder){
        val drawable = GradientDrawable()
        drawable.gradientType = LINEAR_GRADIENT
        drawable.shape = RECTANGLE
        drawable.orientation = Orientation.TL_BR

        drawable.colors = intArrayOf(Color.parseColor(pick(color)) ,Color.parseColor(pick(colorEnd)) )
        holder.background.background = drawable

    }

    //we use the function pick to give the right color as exadecimal code so we are able to make the shade effect
    private fun pick(color: String?): String {
        when (color) {
            "electric" -> return "#E5C531"
            "grass" -> return "#71C558"
            "fire" -> return "#EA7A3C"
            "water" -> return "#539AE2"
            "poison" -> return "#B468B7"
            "normal" -> return "#AAB09F"
            "bug" -> return "#94BC4A"
            "ground" -> return "#CC9F4F"
            "flying" -> return "#7DA6DE"
            "fairy" -> return "#E397D1"
            "dragon" -> return "#6A7BAF"
            "ghost" -> return "#846AB6"
            "dark" -> return "#736C75"
            "steel" -> return "#89A1B0"
            "fighting" -> return "#CB5F48"
            "psychic" -> return "#E5709B"
            "rock" -> return "#B2A061"
            "ice" -> return "#70CBD4"
        }
        return "#DCDCDC"
    }


    //this function set all selected item as prefer one
    fun setFavoriteAllSelected() {
        if(selectedList.size() == 0){
            return
        }
        for(i in 0..pokedex.size-1){
            if (selectedList[i, false]) {
                pokedexVM.setFavorite(i)
            }
        }
        selectedList.clear()
    }

    //this function is called during the on back of the pokeshow activity to update favorites
    fun updateImageFavorites(pos: Int){
        val oldFavoriteValue = pokedexVM.lista.value!![pos].favorite
        CoroutineScope(Dispatchers.IO).launch{
            val newFavoriteValue = db.pokeDao().loadFavoriteValueOf(pokedexVM.lista.value!![pos].name)
            launch(Dispatchers.Main) {
                if(oldFavoriteValue != newFavoriteValue){
                pokedexVM.lista.value!![pos].favorite = when(pokedexVM.lista.value!![pos].favorite){
                    0 -> 1
                    else -> 0
                }
                notifyItemChanged(pos)
                }
            }
        }
    }

    //this function set all selected item as not favorite
    fun unsetFavoriteAllSelected() {
        if(selectedList.size() == 0){
            return
        }
        for(i in 0..pokedex.size-1){
            if (selectedList[i, false]) {
                pokedexVM.unsetFavorite(i)
            }
        }
        selectedList.clear()
    }

    fun deselectAll() {
        selectedList.clear()
        notifyDataSetChanged()
    }

}