package it.gtplay.pokemon.adapter


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import it.gtplay.pokemon.persistence.JoinPokeMove
import it.gtplay.pokemon.R
import it.gtplay.pokemon.fragments.MovesFragment
import java.util.*


class MovesAdapter(var moves: MutableList<JoinPokeMove>, val context: MovesFragment) :
    RecyclerView.Adapter<MovesAdapter.Holder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {

        val constraintLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.move_card, parent, false) as ConstraintLayout

        return Holder(constraintLayout)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        //take data from the mutable list and populate the item card
        holder.name.text = moves[position].move.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
        holder.power.text = moves[position].power.toString()
        holder.pp.text = moves[position].pp.toString()
        holder.category.text = moves[position].damage_type.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
        holder.accuracy.text = moves[position].accuracy.toString()
        holder.type.text = moves[position].type_name.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
        holder.level.text = moves[position].level.toString()
        holder.method.text = moves[position].method.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
        holder.name.setTextColor(ContextCompat.getColor(context.requireActivity(), pick(moves[position].type_name)))
    }

    override fun getItemCount(): Int {
        return moves.size
    }

    private fun pick(color: String?): Int {
        when(color){
            "electric" -> return R.color.electro
            "grass" ->return R.color.grass
            "fire" ->return R.color.fire
            "water" ->return R.color.water
            "poison" ->return R.color.poison
            "normal" ->return R.color.normal
            "bug" ->return R.color.bug
            "ground" ->return R.color.ground
            "flying" ->return R.color.flying
            "fairy" ->return R.color.fairy
            "dragon" ->return R.color.dragon
            "ghost" ->return R.color.ghost
            "dark" ->return R.color.dark
            "steel" ->return R.color.steel
            "fighting" ->return R.color.fighting
            "psychic" ->return R.color.psychic
            "rock" ->return R.color.rock
            "ice" ->return R.color.ice

        }
        return R.color.grass
    }


    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val name: TextView = itemView.findViewById(R.id.name)
        val power: TextView = itemView.findViewById(R.id.power)
        val pp: TextView = itemView.findViewById(R.id.pp)
        val type: TextView = itemView.findViewById(R.id.type)
        val category: TextView = itemView.findViewById(R.id.category)
        val accuracy: TextView = itemView.findViewById(R.id.accuracy)
        val level: TextView = itemView.findViewById(R.id.level)
        val method: TextView = itemView.findViewById(R.id.method)
    }
}