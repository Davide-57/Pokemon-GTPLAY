package it.gtplay.pokemon

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import it.gtplay.pokemon.persistence.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONException


class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_screen)
        if (supportActionBar != null)
            supportActionBar?.hide()


        window.statusBarColor = ContextCompat.getColor(this,R.color.grass)
        window.navigationBarColor = ContextCompat.getColor(this, R.color.grass)

        //variables foe check of internet before playSoundPokemon
        val cm = this.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork: Network? = cm.activeNetwork
        val isConnected = activeNetwork != null

        val db = DbPokemon.getInstance(this)
        CoroutineScope(Dispatchers.IO).launch {
            launch(Dispatchers.IO){
                delay(500)
                if (db.pokeDao().recordsPokemon() == 0 && db.pokeDao().recordsMove() == 0 && db.pokeDao().recordsPokeMove() == 0 && db.pokeDao().recordsEvolution() == 0) {
                    if(!isConnected) {
                        launch(Dispatchers.Main) {

                            //when we have no database and no internet connection, alert dialog provide us a feedback and force us to restart app with internet connection
                            AlertDialog.Builder(this@SplashScreen)
                                .setTitle(getString(R.string.noInternet))
                                .setMessage(getString(R.string.reopenApp))
                                .setPositiveButton(getString(R.string.restart)) { _, _ ->
                                    val intent = Intent(this@SplashScreen, SplashScreen::class.java)
                                    startActivity(intent)
                                    finish()
                                }
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show()
                        }
                    }

                    else{
                        val intent = Intent(this@SplashScreen, MainActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                }


                else if(this@SplashScreen.getSharedPreferences("setting", MODE_PRIVATE).getInt("tutorial", 0) == 1){
                    //if the db is not empty and the user has already provided his personal data
                    delay(2000)
                    if(isConnected) {
                        if (checkUpdate() == 1) {
                            val intent = Intent(this@SplashScreen, Home::class.java)
                            startActivity(intent)
                            finish()
                        } else {
                            val intent = Intent(this@SplashScreen, Update::class.java)
                            startActivity(intent)
                            finish()
                        }
                    }else{
                        if (checkLastCheck() == 1){
                            launch(Dispatchers.Main) {
                                AlertDialog.Builder(this@SplashScreen)
                                    .setTitle(getString(R.string.noInternet))
                                    .setMessage(getString(R.string.reopenAppAlsoUpdate))
                                    .setPositiveButton(getString(R.string.restart)) { _, _ ->
                                        val intent =
                                            Intent(this@SplashScreen, SplashScreen::class.java)
                                        startActivity(intent)
                                        finish()
                                    }
                                    .setIcon(android.R.drawable.ic_dialog_alert)
                                    .show()
                            }
                        }
                        else {
                            val intent = Intent(this@SplashScreen, Home::class.java)
                            startActivity(intent)
                            finish()
                        }
                    }

                }
                else{
                    //if the db is not empty and the user hasn't already provided his personal data
                    if(isConnected) {
                        if (checkUpdate() == 1) {
                            val intent = Intent(this@SplashScreen, MainActivity::class.java)
                            intent.putExtra("database",1 )
                            startActivity(intent)
                            finish()
                        } else {
                            val intent = Intent(this@SplashScreen, MainActivity::class.java)
                            startActivity(intent)
                            finish()
                        }
                    }else{
                        if (checkLastCheck() == 1){
                            launch(Dispatchers.Main) {
                                AlertDialog.Builder(this@SplashScreen)
                                    .setTitle(getString(R.string.noInternet))
                                    .setMessage(getString(R.string.reopenAppAlsoUpdate))
                                    .setPositiveButton(getString(R.string.restart)) { _, _ ->
                                        val intent =
                                            Intent(this@SplashScreen, SplashScreen::class.java)
                                        startActivity(intent)
                                        finish()
                                    }
                                    .setIcon(android.R.drawable.ic_dialog_alert)
                                    .show()
                            }

                        }
                        else {
                            val intent = Intent(this@SplashScreen, Home::class.java)
                            startActivity(intent)
                            finish()
                        }
                    }
                }
            }
        }
    }
    //checkUpdate function return 1 when the update is not necessary
    private fun checkUpdate(): Int {
        val db = DbPokemon.getInstance(this)
        val urlCountPokemon = "https://pokeapi.co/api/v2/pokemon-species/"
        val requestQueue = Volley.newRequestQueue(this)
        var numOfPokemon : Int
        var numOfPokemonInDb: Int

        var check = 0
        var end = 0

        CoroutineScope(Dispatchers.IO).launch {
            numOfPokemonInDb = db.pokeDao().recordsPokemon()
            val requestCountPokemon = JsonObjectRequest(Request.Method.GET, urlCountPokemon, null, { response1 ->
                try {
                    CoroutineScope(Dispatchers.IO).launch {
                        numOfPokemon = response1.getInt("count")
                        if (numOfPokemon == numOfPokemonInDb ){
                            check = 1
                        }
                        else{
                            db.pokeDao().deleteAll()
                            db.pokeDao().deleteMove()
                            db.pokeDao().deletePokemonMoves()
                            db.pokeDao().deleteEvolutionChain()
                        }
                        end = 1
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            }, { error -> error.printStackTrace() })
            requestQueue?.add(requestCountPokemon)
        }
        while (true) {
            if (end == 1) return check
        }
    }
    private fun checkLastCheck(): Int {
        val db = DbPokemon.getInstance(this)
        var numOfPokemonInDb: Int

        var check = 1
        var end = 0

        val sharedPref = this@SplashScreen.getSharedPreferences("setting",Context.MODE_PRIVATE)
        val prevStoredDatabase =  sharedPref.getInt("lenDb", 0)

        CoroutineScope(Dispatchers.IO).launch {
            numOfPokemonInDb = db.pokeDao().recordsPokemon()
            if (numOfPokemonInDb >=prevStoredDatabase){
                check = 0
            }
            else{
                db.pokeDao().deleteAll()
                db.pokeDao().deleteMove()
                db.pokeDao().deletePokemonMoves()
                db.pokeDao().deleteEvolutionChain()
            }
            end = 1
        }
        while (true) {
            if (end == 1) return check
        }
    }
}