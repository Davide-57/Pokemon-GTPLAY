package it.gtplay.pokemon.fragments

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import it.gtplay.pokemon.R
import it.gtplay.pokemon.databinding.FragmentNameBinding
import it.gtplay.pokemon.viewModel.TrainerViewModel


class NameFragment : Fragment(), IntroToMain{
    private lateinit var binding: FragmentNameBinding

    private val model: TrainerViewModel by viewModels()
    private lateinit var mListener: IntroToMain

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mListener = if(context is IntroToMain)
            context
        else
            this
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentNameBinding.inflate(layoutInflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        //In the last fragment user selected a character, so now we change background with color associated to it, water color when boy, poison color when girl
        val preferences = context?.getSharedPreferences("setting", Context.MODE_PRIVATE)
        val gen = preferences?.getInt("gender", 2)
        if (gen == 1){
            binding.layout.backgroundTintList = resources.getColorStateList(R.color.water,null)
            binding.title.setTextColor(resources.getColorStateList(R.color.white,null))
            binding.trainer.setImageResource(R.drawable.boy)
        }
        else if(gen == 0){
            binding.layout.backgroundTintList = resources.getColorStateList(R.color.poison,null)
            binding.title.setTextColor(resources.getColorStateList(R.color.white,null))
            binding.trainer.setImageResource(R.drawable.girl)
        }
        //user provides name in the edit text so we have to check it to store the name inside shared preferences
        val textview: EditText = binding.textinsert
        textview.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                prefer(binding.textinsert.text.toString())
            }
            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                prefer(binding.textinsert.text.toString())
                if(cs.isNotEmpty()){
                    model.messageTerminated.value = mutableListOf(1,0)
                }
                else{
                    model.messageTerminated.value = mutableListOf(0,0)
                }
            }
            override fun afterTextChanged(arg0: Editable) {
                prefer(binding.textinsert.text.toString())
            }
        })
        val observer = Observer<MutableList<Int>> { list ->
            mListener.endMessage(list)
        }
        model.messageTerminated.observe(requireActivity(), observer)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onResume() {
        val preferences = context?.getSharedPreferences("setting", Context.MODE_PRIVATE)
        val gen = preferences?.getInt("gender", 1)
        if ( gen == 1){
            binding.layout.backgroundTintList = resources.getColorStateList(R.color.water,null)
            binding.title.setTextColor(resources.getColorStateList(R.color.white,null))
            binding.trainer.setImageResource(R.drawable.boy)
        }
        else{
            binding.layout.backgroundTintList = resources.getColorStateList(R.color.poison,null)
            binding.title.setTextColor(resources.getColorStateList(R.color.white,null))
            binding.trainer.setImageResource(R.drawable.girl)
        }

        super.onResume()
    }

    //store data in shared preferences
    private fun prefer(name: String){
        val sharedPref = this.requireActivity().getSharedPreferences("setting",Context.MODE_PRIVATE)
        sharedPref.edit().putString("name", name).apply()
    }

    override fun endMessage(list: MutableList<Int>) {
        TODO("Not yet implemented")
    }
}