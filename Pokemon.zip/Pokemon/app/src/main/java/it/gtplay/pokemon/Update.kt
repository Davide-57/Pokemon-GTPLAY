package it.gtplay.pokemon


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import it.gtplay.pokemon.databinding.ActivityUpdateBinding
import it.gtplay.pokemon.fragments.*
import it.gtplay.pokemon.persistence.*
import it.gtplay.pokemon.viewModel.CommViewModel
import kotlinx.coroutines.*
import org.json.JSONException
import kotlin.math.roundToInt

@Suppress("NAME_SHADOWING")
class Update : AppCompatActivity(), IntroToMain {

    private lateinit var binding: ActivityUpdateBinding
    private val viewModel: CommViewModel by viewModels()


    private var downloadIsTerminated = false

    override fun endMessage(list: MutableList<Int>) {
        viewModel.updateData(list)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUpdateBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (supportActionBar != null)
            supportActionBar?.hide()

        window.statusBarColor = ContextCompat.getColor(this, R.color.water)
        val db = DbPokemon.getInstance(this)
        val gson = Gson()
        val urlCountPokemon = "https://pokeapi.co/api/v2/pokemon-species/"
        val urlCountMoves = "https://pokeapi.co/api/v2/move/"
        val baseUrlPoke = "https://pokeapi.co/api/v2/pokemon/"
        val baseUrlMove = "https://pokeapi.co/api/v2/move/"
        val urlEvolutionUrl = "https://pokeapi.co/api/v2/evolution-chain?limit=467"
        val requestQueue = Volley.newRequestQueue(this)


        var numOfPokemon = 898      //expected value only for the progressbar, number of volley responses to process
        var actualNumOfPokemon = 0  //number of elaborated volley responses
        var statusPokemon = 0       //if all volley requests are elaborated then statusPokemon is 1

        var numOfMoves = 826        //expected value only for the progressbar, number of volley responses to process
        var actualNumOfMoves = 0    //number of elaborated volley responses
        val numMovesNoMainLine = 18
        var statusMove = 0          //if all volley requests are elaborated then statusMove is 1

        var numOfEvolutionChain = 467        //expected value only for the progressbar, number of volley responses to process
        var actualNumOfEvolutionChain = 0    //number of elaborated volley responses
        var statusEvolutionChain = 0         //if all volley requests are elaborated then statusEvolution is 1

        CoroutineScope(Dispatchers.IO).launch {
            //if db is empty
            if(db.pokeDao().recordsPokemon() == 0){
                //insert pokemon in db
                val requestCountPokemon = JsonObjectRequest(Request.Method.GET, urlCountPokemon, null, { response1 ->
                    try {
                        CoroutineScope(Dispatchers.IO).launch {

                            //update number of pokemon available
                            numOfPokemon = response1.getInt("count")
                            val sharedPref = this@Update.getSharedPreferences("setting", Context.MODE_PRIVATE)
                            sharedPref.edit().putInt("lenDb", numOfPokemon).apply()

                            //for every pokemon
                            for (i in 1..numOfPokemon) {
                                val requestPokemon = JsonObjectRequest(Request.Method.GET, baseUrlPoke + i.toString(), null, { response2 ->
                                    try {
                                        //this code take with Gson variables : id, height ,weight
                                        val pokemon: Pokemon = gson.fromJson(response2.toString(), Pokemon::class.java)
                                        pokemon.url = baseUrlPoke + i.toString()

                                        val jaStats = response2.getJSONArray("stats")
                                        pokemon.hp = jaStats.getJSONObject(0).getInt("base_stat")
                                        pokemon.atk = jaStats.getJSONObject(1).getInt("base_stat")
                                        pokemon.def = jaStats.getJSONObject(2).getInt("base_stat")
                                        pokemon.atks = jaStats.getJSONObject(3).getInt("base_stat")
                                        pokemon.defs = jaStats.getJSONObject(4).getInt("base_stat")
                                        pokemon.speed = jaStats.getJSONObject(5).getInt("base_stat")

                                        val jaAbilities = response2.getJSONArray("abilities")
                                        pokemon.ability1 = jaAbilities.getJSONObject(0).getJSONObject("ability").getString("name")
                                        //if the pokemon has two abilities
                                        if(jaAbilities.length()>1){
                                            pokemon.ability2 = jaAbilities.getJSONObject(1).getJSONObject("ability").getString("name")
                                        }
                                        else pokemon.ability2 = ""

                                        val jaTypes = response2.getJSONArray("types")
                                        pokemon.type1 = jaTypes.getJSONObject(0).getJSONObject("type").getString("name")
                                        //if the pokemon has two types
                                        if(jaTypes.length()==2){
                                            pokemon.type2 = jaTypes.getJSONObject(1).getJSONObject("type").getString("name")
                                        }

                                        CoroutineScope(Dispatchers.IO).launch {
                                            db.pokeDao().insert(pokemon)
                                        }


                                        val pokeMove = PokemonMoves()
                                        pokeMove.pokemon = pokemon.name
                                        val jaMoves = response2.getJSONArray("moves")
                                        val lenJaMoves = jaMoves.length()

                                        //insert the association between pokemon and his moves
                                        CoroutineScope(Dispatchers.IO).launch {
                                            for(i in 0..lenJaMoves - 1){
                                                pokeMove.move = jaMoves.getJSONObject(i).getJSONObject("move").getString("name")
                                                pokeMove.level = jaMoves.getJSONObject(i).getJSONArray("version_group_details").getJSONObject(0).getInt("level_learned_at")
                                                pokeMove.method = jaMoves.getJSONObject(i).getJSONArray("version_group_details").getJSONObject(0).getJSONObject("move_learn_method").getString("name")
                                                db.pokeDao().insertPokemonMoves(pokeMove)
                                            }
                                        }

                                        //another volley response is elaborated
                                        actualNumOfPokemon += 1

                                    } catch (e: JSONException) {
                                        e.printStackTrace()
                                    }
                                },
                                    { error -> error.printStackTrace() })
                                requestQueue?.add(requestPokemon)
                            }
                            launch(Dispatchers.IO) {
                                while (true) {
                                    if (actualNumOfPokemon == numOfPokemon) {
                                        statusPokemon = 1
                                        break
                                    } else delay(1000)
                                }
                            }
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }, { error -> error.printStackTrace() })
                requestQueue?.add(requestCountPokemon)



                //insert moves in db after the pokemon's inserts

                val requestCountMoves = JsonObjectRequest(Request.Method.GET, urlCountMoves, null, { responseCountMoves ->
                    CoroutineScope(Dispatchers.IO).launch {
                        numOfMoves = responseCountMoves.getInt("count")
                        for (i in 1..(numOfMoves-numMovesNoMainLine)) {
                            val requestMoves = JsonObjectRequest(Request.Method.GET, baseUrlMove + i.toString(), null, { responseMoves ->
                                try {
                                    //another volley response is elaborated
                                    actualNumOfMoves += 1

                                    //this code take with Gson variables : name, id, power and accuracy
                                    val move: Move = gson.fromJson(responseMoves.toString(), Move::class.java)
                                    move.url = baseUrlMove + i.toString()

                                    move.type_name = responseMoves.getJSONObject("type").getString("name")
                                    move.damage_type = responseMoves.getJSONObject("damage_class").getString("name")

                                    CoroutineScope(Dispatchers.IO).launch {
                                        db.pokeDao().insertMove(move)
                                    }

                                } catch (e: JSONException) {
                                    e.printStackTrace()
                                }
                            },
                                { error -> error.printStackTrace() })
                            requestQueue?.add(requestMoves)

                        }

                        launch(Dispatchers.IO) {
                            while (true) {
                                if (actualNumOfMoves == numOfMoves - numMovesNoMainLine) {
                                    //downloads of moves are finished
                                    statusMove = 1
                                    break
                                } else delay(2000)
                            }
                        }
                    }
                }, { error -> error.printStackTrace() })
                requestQueue?.add(requestCountMoves)



                //request of evolution chain

                val requestEvUrl = JsonObjectRequest(Request.Method.GET, urlEvolutionUrl, null, { responseEvUrl ->
                    CoroutineScope(Dispatchers.IO).launch {
                        val listObject = responseEvUrl.getJSONArray("results")
                        numOfEvolutionChain = responseEvUrl.getInt("count")
                        for (i in 0..listObject.length()-1) {
                            val requestEvChain = JsonObjectRequest(Request.Method.GET, listObject.getJSONObject(i).getString("url"), null, { responseEvChain ->
                                try {
                                    CoroutineScope(Dispatchers.Default).launch {

                                        val evolutionChain = EvolutionChain()

                                        //get all attribute of evolution chain
                                        evolutionChain.base_form = responseEvChain.getJSONObject("chain").getJSONObject("species").getString("name")

                                        val evolvsTo1 = responseEvChain.getJSONObject("chain").getJSONArray("evolves_to")

                                        //the insert of evolution chain of phione and meltan generetes api error. then it will insert
                                        if(evolvsTo1.length() > 0 && evolutionChain.base_form != "phione" && evolutionChain.base_form != "meltan"){
                                            if(evolvsTo1.length() == 1){
                                                //pokemon with only one first evolution
                                                evolutionChain.first_evolution = evolvsTo1.getJSONObject(0).getJSONObject("species").getString("name")
                                                evolutionChain.level1 = evolvsTo1.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).optInt("min_level",0)
                                                if(evolvsTo1.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).optJSONObject("item")!=null){
                                                    evolutionChain.item1 = evolvsTo1.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).getJSONObject("item").getString("name")
                                                }
                                                evolutionChain.happiness1 = evolvsTo1.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).optInt("min_happiness",0)
                                                evolutionChain.method1 = evolvsTo1.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).getJSONObject("trigger").getString("name")


                                                val evolvsTo2 = evolvsTo1.getJSONObject(0).getJSONArray("evolves_to")
                                                if(evolvsTo2.length() > 0){
                                                    if(evolvsTo2.length() == 1){
                                                        //the pokemon has only one kind of second evolution
                                                        evolutionChain.second_evolution = evolvsTo2.getJSONObject(0).getJSONObject("species").getString("name")
                                                        evolutionChain.level2 = evolvsTo2.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).optInt("min_level",0)
                                                        if(evolvsTo2.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).optJSONObject("item")!=null){
                                                            evolutionChain.item2 = evolvsTo2.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).getJSONObject("item").getString("name")
                                                        }
                                                        evolutionChain.happiness2 = evolvsTo2.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).optInt("min_happiness",0)
                                                        evolutionChain.method2 = evolvsTo2.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).getJSONObject("trigger").getString("name")
                                                        launch(Dispatchers.IO){
                                                            db.pokeDao().insertEvolutionChain(evolutionChain)
                                                        }
                                                    }
                                                    else{
                                                        //the pokemon has multiple evolution line for second evolution
                                                        launch(Dispatchers.IO){
                                                            for (i in 0..evolvsTo2.length() - 1) {
                                                                evolutionChain.second_evolution = evolvsTo2.getJSONObject(i).getJSONObject("species").getString("name")
                                                                evolutionChain.level2 = evolvsTo2.getJSONObject(i).getJSONArray("evolution_details").getJSONObject(0).optInt("min_level",0)
                                                                if(evolvsTo2.getJSONObject(i).getJSONArray("evolution_details").getJSONObject(0).optJSONObject("item")!=null){
                                                                    evolutionChain.item2 = evolvsTo2.getJSONObject(i).getJSONArray("evolution_details").getJSONObject(0).getJSONObject("item").getString("name")
                                                                }
                                                                evolutionChain.happiness2 = evolvsTo2.getJSONObject(i).getJSONArray("evolution_details").getJSONObject(0).optInt("min_happiness",0)
                                                                evolutionChain.method2 = evolvsTo2.getJSONObject(i).getJSONArray("evolution_details").getJSONObject(0).getJSONObject("trigger").getString("name")
                                                                db.pokeDao().insertEvolutionChain(evolutionChain)

                                                                evolutionChain.second_evolution = ""
                                                                evolutionChain.level2 = 0
                                                                evolutionChain.item2 = ""
                                                                evolutionChain.happiness2 = 0
                                                                evolutionChain.method2 = ""
                                                            }
                                                        }
                                                    }
                                                }
                                                else{
                                                    //the pokemon has only first evolution
                                                    launch(Dispatchers.IO){
                                                        db.pokeDao().insertEvolutionChain(evolutionChain)
                                                    }
                                                }
                                            }
                                            else{
                                                //pokemon with multiple first evolution line
                                                launch(Dispatchers.IO){
                                                    for (i in 0..evolvsTo1.length() - 1) {

                                                        evolutionChain.first_evolution = evolvsTo1.getJSONObject(i).getJSONObject("species").getString("name")
                                                        evolutionChain.level1 = evolvsTo1.getJSONObject(i).getJSONArray("evolution_details").getJSONObject(0).optInt("min_level",0)
                                                        if(evolvsTo1.getJSONObject(i).getJSONArray("evolution_details").getJSONObject(0).optJSONObject("item")!=null){
                                                            evolutionChain.item1 = evolvsTo1.getJSONObject(i).getJSONArray("evolution_details").getJSONObject(0).getJSONObject("item").getString("name")
                                                        }
                                                        evolutionChain.happiness1 = evolvsTo1.getJSONObject(i).getJSONArray("evolution_details").getJSONObject(0).optInt("min_happiness",0)
                                                        evolutionChain.method1 = evolvsTo1.getJSONObject(i).getJSONArray("evolution_details").getJSONObject(0).getJSONObject("trigger").getString("name")


                                                        val evolvsTo2 = evolvsTo1.getJSONObject(i).getJSONArray("evolves_to")
                                                        //when pokemon has also a second evolution
                                                        if(evolvsTo2.length() > 0){
                                                            evolutionChain.second_evolution = evolvsTo2.getJSONObject(0).getJSONObject("species").getString("name")
                                                            evolutionChain.level2 = evolvsTo2.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).optInt("min_level",0)
                                                            if(evolvsTo2.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).optJSONObject("item")!=null){
                                                                evolutionChain.item2 = evolvsTo2.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).getJSONObject("item").getString("name")
                                                            }
                                                            evolutionChain.happiness2 = evolvsTo2.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).optInt("min_happiness",0)
                                                            evolutionChain.method2 = evolvsTo2.getJSONObject(0).getJSONArray("evolution_details").getJSONObject(0).getJSONObject("trigger").getString("name")
                                                        }

                                                        db.pokeDao().insertEvolutionChain(evolutionChain)
                                                        evolutionChain.first_evolution = ""
                                                        evolutionChain.level1 = 0
                                                        evolutionChain.item1 = ""
                                                        evolutionChain.happiness1 = 0
                                                        evolutionChain.method1 = ""

                                                        evolutionChain.second_evolution = ""
                                                        evolutionChain.level2 = 0
                                                        evolutionChain.item2 = ""
                                                        evolutionChain.happiness2 = 0
                                                        evolutionChain.method2 = ""
                                                    }
                                                }
                                            }
                                        }
                                        else if(evolutionChain.base_form != "phione" && evolutionChain.base_form != "meltan"){
                                            //pokemon with no evolution but not phione and meltan
                                            launch(Dispatchers.IO){
                                                db.pokeDao().insertEvolutionChain(evolutionChain)
                                            }
                                        }
                                        else{
                                            //this pokemon is phione or meltan
                                            evolutionChain.first_evolution = evolvsTo1.getJSONObject(0).getJSONObject("species").getString("name")
                                            launch(Dispatchers.IO){
                                                db.pokeDao().insertEvolutionChain(evolutionChain)
                                            }
                                        }
                                        actualNumOfEvolutionChain += 1
                                    }
                                } catch (e: JSONException) {
                                    e.printStackTrace()
                                }
                            },
                                { error -> error.printStackTrace() })
                            requestQueue?.add(requestEvChain)

                        }

                        launch(Dispatchers.IO) {
                            while (true) {
                                if (actualNumOfEvolutionChain == numOfEvolutionChain) {
                                    statusEvolutionChain = 1
                                    break
                                } else delay(2000)
                            }
                        }
                    }
                }, { error -> error.printStackTrace() })
                requestQueue?.add(requestEvUrl)

                launch(Dispatchers.Main) {
                    while(true){
                        //if info download is terminated
                        if(statusMove == 1 && statusPokemon == 1 && statusEvolutionChain == 1){
                            var percent = ((actualNumOfPokemon+actualNumOfMoves+actualNumOfEvolutionChain)*1f/(numOfPokemon+numOfMoves-numMovesNoMainLine+numOfEvolutionChain)*1f)* 100f
                            percent = ((percent * 10f).roundToInt())/10f
                            downloadIsTerminated = true
                            binding.tv.text = percent.toString()
                            binding.progressBar.setProgress(percent.toInt(), true)

                            // if tutorial is done
                            if(this@Update.getSharedPreferences("setting", MODE_PRIVATE).getInt("tutorial", 0) == 1){
                                val intent = Intent(this@Update, Home::class.java)
                                startActivity(intent)
                                finish()
                            }
                            else{
                                // if tutorial is ont done
                                val intent = Intent(this@Update, MainActivity::class.java)
                                intent.putExtra("database",1 )
                                startActivity(intent)
                                finish()
                            }
                            break
                        }
                        else { // download not terminated
                            var percent = ((actualNumOfPokemon+actualNumOfMoves+actualNumOfEvolutionChain)*1f/(numOfPokemon+numOfMoves-numMovesNoMainLine+numOfEvolutionChain)*1f)* 100f
                            percent = ((percent * 100f).roundToInt())/100f
                            binding.tv.text = percent.toString()
                            binding.progressBar.setProgress(percent.toInt(), true)
                            delay(2000)
                        }
                    }
                }
            }
        }
    }
}