package it.gtplay.pokemon.persistence

import androidx.room.Entity
import androidx.room.PrimaryKey



@Entity
data class Pokemon (@PrimaryKey var name: String,
                    var id: Int,
                    var url: String,
                    var height: Int,
                    var weight: Int,
                    var hp: Int, var atk: Int, var def: Int,var atks: Int,var defs: Int,var speed: Int,
                    var type1: String,
                    var type2: String?,
                    var ability1: String,
                    var ability2: String,
                    var favorite: Int){
    constructor(valueName: String,valueId: Int,valueTypeOne: String,valueTypeTwo: String) : this("",0,"",0,0,0,0,0,0,0,0,"","","","",0) {
        name =valueName
        id = valueId
        type1 = valueTypeOne
        type2 = valueTypeTwo
    }
}

