package it.gtplay.pokemon.viewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import it.gtplay.pokemon.persistence.DbPokemon
import it.gtplay.pokemon.persistence.Pokemon
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PokemonVM(application:Application) : AndroidViewModel(application) {
    var lista: MutableLiveData<MutableList<Pokemon>> = MutableLiveData()


    fun setFavorite(i: Int){
        val name: String = lista.value?.get(i)?.name.toString()
        lista.value?.get(i)?.favorite = 1
        val db = DbPokemon.getInstance(getApplication())
        CoroutineScope(Dispatchers.IO).launch{
            db.pokeDao().setFavorite(name)
        }
    }

    fun unsetFavorite(i: Int){
        val name: String = lista.value?.get(i)?.name.toString()
        lista.value?.get(i)?.favorite = 0
        val db = DbPokemon.getInstance(getApplication())
        CoroutineScope(Dispatchers.IO).launch{
            db.pokeDao().unsetFavorite(name)
        }
    }


    fun filter(
        p0: String?,
        statusType: Int,
        type: String,
        statusFavorite: Int,
        statusReverse: Int,
        statusId: Int
    ) {
        //filterString = p0!!
        val db = DbPokemon.getInstance(getApplication())
        var theList: MutableList<Pokemon>
        CoroutineScope(Dispatchers.IO).launch {
            //this if is necessary to show the filtered list when there isn't character in search string
            if (p0 == "") {
                //there are 4 cases to consider. every case is dependent by statusFavorite and statusType
                if (statusId == 1) {
                    //if the base order is by id
                    if (statusReverse == 0) {
                        //not reversed
                        if (statusFavorite == 0 && statusType == 0) {
                            theList = db.pokeDao().loadOrdered()

                        } else if (statusFavorite == 1 && statusType == 0) {
                            theList = db.pokeDao().loadFavorites()

                        } else if (statusFavorite == 0 && statusType == 1) {
                            theList = db.pokeDao().loadAllByType(type)

                        } else {
                            theList = db.pokeDao().loadFavoritesByType(type)

                        }
                        CoroutineScope(Dispatchers.Main).launch {
                            lista.value = theList
                        }
                    } else {
                        //reversed
                        if (statusFavorite == 0 && statusType == 0) {
                            theList = db.pokeDao().loadOrdered().asReversed()
                        } else if (statusFavorite == 1 && statusType == 0) {
                            theList = db.pokeDao().loadFavorites().asReversed()
                        } else if (statusFavorite == 0 && statusType == 1) {
                            theList = db.pokeDao().loadAllByType(type).asReversed()
                        } else {
                            theList = db.pokeDao().loadFavoritesByType(type).asReversed()
                        }
                        CoroutineScope(Dispatchers.Main).launch {
                            lista.value = theList
                        }
                    }
                } else {
                    //else the base order is by az
                    if (statusReverse == 0) {
                        //not reversed
                        if (statusFavorite == 0 && statusType == 0) {
                            theList = db.pokeDao().loadOrderedAtoZ()

                        } else if (statusFavorite == 1 && statusType == 0) {
                            theList = db.pokeDao().loadFavoritesAtoZ()

                        } else if (statusFavorite == 0 && statusType == 1) {
                            theList = db.pokeDao().loadOrderedTypeAtoZ(type)

                        } else {
                            theList = db.pokeDao().loadFavoritesByTypeAtoZ(type)
                        }
                        CoroutineScope(Dispatchers.Main).launch {
                            lista.value = theList
                        }
                    } else {
                        //reversed
                        if (statusFavorite == 0 && statusType == 0) {
                            theList = db.pokeDao().loadOrderedAtoZ().asReversed()
                        } else if (statusFavorite == 1 && statusType == 0) {
                            theList = db.pokeDao().loadFavoritesAtoZ().asReversed()

                        } else if (statusFavorite == 0 && statusType == 1) {
                            theList = db.pokeDao().loadOrderedTypeAtoZ(type).asReversed()

                        } else {
                            theList = db.pokeDao().loadFavoritesByTypeAtoZ(type).asReversed()

                        }
                        CoroutineScope(Dispatchers.Main).launch {
                            lista.value = theList
                        }
                    }
                }
            }



            else if (p0 != null) {
                if (statusId == 1) {
                    //if the base order is by id
                    if (statusReverse == 0) {
                        //not reversed
                        if (statusFavorite == 0 && statusType == 0) {
                            theList = db.pokeDao().loadAllByName(String.format("%s%%", p0))

                        } else if (statusFavorite == 1 && statusType == 0) {
                            theList = db.pokeDao().loadFavoritesByName(String.format("%s%%", p0))

                        } else if (statusFavorite == 0 && statusType == 1) {
                            theList = db.pokeDao().loadTypedByName(String.format("%s%%", p0), type)

                        } else {
                            theList = db.pokeDao()
                                .loadFavoritesTypedByName(String.format("%s%%", p0), type)
                        }
                        CoroutineScope(Dispatchers.Main).launch {
                            lista.value = theList
                        }
                    } else {
                        //reversed
                        if (statusFavorite == 0 && statusType == 0) {
                            theList =
                                db.pokeDao().loadAllByName(String.format("%s%%", p0)).asReversed()

                        } else if (statusFavorite == 1 && statusType == 0) {
                            theList = db.pokeDao().loadFavoritesByName(String.format("%s%%", p0))
                                .asReversed()

                        } else if (statusFavorite == 0 && statusType == 1) {
                            theList = db.pokeDao().loadTypedByName(String.format("%s%%", p0), type)
                                .asReversed()

                        } else {
                            theList = db.pokeDao()
                                .loadFavoritesTypedByName(String.format("%s%%", p0), type)
                                .asReversed()
                        }
                        CoroutineScope(Dispatchers.Main).launch {
                            lista.value = theList
                        }
                    }
                } else {
                    //else the base order is by az
                    if (statusReverse == 0) {
                        //not reversed
                        if (statusFavorite == 0 && statusType == 0) {
                            theList = db.pokeDao().loadOrderedAtoZByName(String.format("%s%%", p0))

                        } else if (statusFavorite == 1 && statusType == 0) {
                            theList =
                                db.pokeDao().loadFavoritesAtoZByName(String.format("%s%%", p0))

                        } else if (statusFavorite == 0 && statusType == 1) {
                            theList = db.pokeDao()
                                .loadOrderedTypeAtoZByName(String.format("%s%%", p0), type)

                        } else {
                            theList = db.pokeDao()
                                .loadFavoritesByTypeAtoZByName(String.format("%s%%", p0), type)

                        }
                        CoroutineScope(Dispatchers.Main).launch {
                            lista.value = theList
                        }
                    } else {
                        //reversed
                        if (statusFavorite == 0 && statusType == 0) {
                            theList = db.pokeDao().loadOrderedAtoZByName(String.format("%s%%", p0))
                                .asReversed()
                        } else if (statusFavorite == 1 && statusType == 0) {
                            theList =
                                db.pokeDao().loadFavoritesAtoZByName(String.format("%s%%", p0))
                                    .asReversed()

                        } else if (statusFavorite == 0 && statusType == 1) {
                            theList = db.pokeDao()
                                .loadOrderedTypeAtoZByName(String.format("%s%%", p0), type)
                                .asReversed()

                        } else {
                            theList = db.pokeDao()
                                .loadFavoritesByTypeAtoZByName(String.format("%s%%", p0), type)
                                .asReversed()
                        }
                        CoroutineScope(Dispatchers.Main).launch {
                            lista.value = theList
                        }
                    }
                }
            }
        }
    }
}