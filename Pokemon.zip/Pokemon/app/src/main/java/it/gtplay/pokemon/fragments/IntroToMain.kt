package it.gtplay.pokemon.fragments

interface IntroToMain {
    fun endMessage(list: MutableList<Int>)
}