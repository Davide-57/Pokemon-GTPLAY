package it.gtplay.pokemon.persistence

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase


@Database(entities = [Pokemon::class, Move::class, PokemonMoves::class, EvolutionChain::class], version = 1, exportSchema = true)
abstract class DbPokemon : RoomDatabase() {
    companion object {
        private var db: DbPokemon? = null // Singleton
        fun getInstance(context: Context): DbPokemon {
            if (db == null)
                db = Room.databaseBuilder(
                    context.applicationContext,
                    DbPokemon::class.java,
                    "pokemon.db"
                )
                    //.createFromAsset("databases/p2.db")
                    .build()
            return db as DbPokemon
        }
    }
    abstract fun pokeDao(): DaoPokemon
}

